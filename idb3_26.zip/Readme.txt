Thank you for downloading InstantDB!

STEP 1: PLEASE REVIEW THE EPL LICENSE
--------------------------------------
Before using InstantDB, please review the EPL license agreement at:
http://instantdb.enhydra.org/software/license/index.html

STEP 2: PLEASE FOLLOW THE INSTALLATION 
--------------------------------------
Refer to docs/install.html.

These installation instructions apply specifically to this release and 
they supercede the instructions currently available on the InstantDB web 
site.

STEP 3: READ THE "WHAT'S NEW" SECTION
--------------------------------------
Refer to docs/release-notes.html

This contains information on what's new in this release and what bugs have 
been fixed.

_____________________________________________________________________
For complete documentation on using InstantDB, see:
http://instantdb.enhydra.org/software/documentation/index.html

To join the InstantDB mailing lists, see:
http://instantdb.enhydra.org/project/mailingLists/index.html
_____________________________________________________________________


