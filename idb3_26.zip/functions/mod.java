/*-----------------------------------------------------------------------------
 *
 * Enhydra InstantDB
 * The Initial Developer of the Original Code is Lutris Technologies Inc.
 * Portions created by Lutris are Copyright 1997-2000 Lutris Technologies Inc.
 * All Rights Reserved.
 *
 * The contents of this file are subject to the Enhydra Public License
 * Version 1.1 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 * www.enhydra.org/license/epl.html
 *
 * Software distributed under the License is distributed on an "ASIS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * -----------------------------------------------------------------------------
 * $Id: mod.java,v 1.3 2000/08/09 12:51:28 pete Exp $
 * -----------------------------------------------------------------------------
 */
package org.enhydra.instantdb.db;

import org.enhydra.instantdb.db.SqlFunction;
import java.sql.SQLException;

/**
 * To_date implements the expression function:
 *
 *	MOD (numeric expr, numeric expr).
 */
class mod implements SqlFunction {
  String usage = "MOD requires two numeric parameters";

	public int checkParameters (int[] parameterTypes) throws SQLException {
		int paramCount = parameterTypes.length;				// get number of parameters
		if (paramCount != 2) {								// check parameter count
			throw new SQLException (usage);
		} // if
		if ((parameterTypes[0] == TYPE_STRING) || (parameterTypes[1] == TYPE_STRING)) {				// check allowed param types
			throw new SQLException (usage);
		} // if
    if ((parameterTypes[0] == TYPE_INTEGER) && (parameterTypes[1] == TYPE_INTEGER)) {
		  return TYPE_INTEGER;									// our return type
    } else {
      return TYPE_DOUBLE;
    }
	} // checkParameters

	public void setSpecialValue (int type, Object value) throws SQLException {
	} // setSpecialValue

	public Object getSpecialValue (int type) throws SQLException {
		return null;
	} // getSpecialValue


	public Object evaluate(Object[] parameters) throws SQLException {
    if ((parameters[0] instanceof Integer) && (parameters[1] instanceof Integer)) {
      Integer n1 = (Integer)parameters[0];
		  Integer n2 = (Integer)parameters[1];
      Integer res = new Integer(n1.intValue() % n2.intValue());
      return res;
    } else {
    	Number n1 = (Number)parameters[0];
			Number n2 = (Number)parameters[1];
		  double d1 = n1.doubleValue();
		  double d2 = n2.doubleValue();
		  Double res = new Double (d1 % d2);
		  return res;
    }
	} // evaluate


} // class mod
