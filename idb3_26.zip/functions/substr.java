/*-----------------------------------------------------------------------------
 *
 * Enhydra InstantDB
 * The Initial Developer of the Original Code is Lutris Technologies Inc.
 * Portions created by Lutris are Copyright 1997-2000 Lutris Technologies Inc.
 * All Rights Reserved.
 *
 * The contents of this file are subject to the Enhydra Public License
 * Version 1.1 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 * www.enhydra.org/license/epl.html
 *
 * Software distributed under the License is distributed on an "ASIS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * -----------------------------------------------------------------------------
 * $Id: substr.java,v 1.3 2000/08/09 12:51:28 pete Exp $
 * -----------------------------------------------------------------------------
 */
package org.enhydra.instantdb.db;

import org.enhydra.instantdb.db.SqlFunction;
import java.sql.SQLException;

/**
 * To_date implements the expression function:
 *
 *	SUBSTR (string expr, start [,length]).
 */
class substr implements SqlFunction {

	public int checkParameters (int[] parameterTypes) throws SQLException {
		int paramCount = parameterTypes.length;				// get number of parameters
		String usage = "usage SUBSTR (string, lower [,length])";
		if ((paramCount != 2) && (paramCount != 3)) {		// check parameter count
			throw new SQLException (usage);
		} // if
		if (parameterTypes[0] != TYPE_STRING) {				// check allowed param types
			throw new SQLException (usage);
		} // if
		if (parameterTypes[1] == TYPE_STRING) {				// check allowed param types
			throw new SQLException (usage);
		} // if
		if (paramCount == 3) {								// check final parameter if present
			if (parameterTypes[2] == TYPE_STRING) {
				throw new SQLException (usage);
			} // if
		} // if
		return TYPE_STRING;									// our return type
	} // checkParameters 

	public void setSpecialValue (int type, Object value) throws SQLException {
	} // setSpecialValue

	public Object getSpecialValue (int type) throws SQLException {
		return null;
	} // getSpecialValue


	public Object evaluate(Object[] parameters) throws SQLException {
		String result = null;
		String fullString = parameters[0].toString();
		int lower = ((Integer)parameters[1]).intValue();
		if (parameters.length == 2) {
			result = fullString.substring (lower-1);
		} else {
			int length = ((Integer)parameters[2]).intValue();
			result = fullString.substring (lower-1, lower+length-1);
		} // if-else
		return result;
	} // evaluate


} // class substr 
