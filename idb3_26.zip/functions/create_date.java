/*-----------------------------------------------------------------------------
 *
 * Enhydra InstantDB
 * The Initial Developer of the Original Code is Lutris Technologies Inc.
 * Portions created by Lutris are Copyright 1997-2000 Lutris Technologies Inc.
 * All Rights Reserved.
 *
 * The contents of this file are subject to the Enhydra Public License
 * Version 1.1 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 * www.enhydra.org/license/epl.html
 *
 * Software distributed under the License is distributed on an "ASIS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * -----------------------------------------------------------------------------
 * $Id: create_date.java,v 1.3 2000/08/09 12:51:27 pete Exp $
 * -----------------------------------------------------------------------------
 */
package org.enhydra.instantdb.db;

import org.enhydra.instantdb.db.SqlFunction;
import java.util.Date;
import java.util.Calendar;
import java.sql.SQLException;

/**
 * this class is a SQL-function class which is used for InstantDB
 * to use in SQL. It creates a date. 
 * You can use it like this CREATE_DATE(1970, 1, 1)
 * for the first day in the first month in year 1970
 */
public class create_date implements SqlFunction
{
   private String errUsage = "Error: To get a specific date use CREATE_DATE(1970,1,1).";
   
   public int checkParameters(int[] parameterTypes) throws SQLException
   {
      if (parameterTypes.length != 3)
      {
         throw new SQLException(errUsage);
      }
      
      for (int i = 0; i < parameterTypes.length; i++)
      {
         if (parameterTypes[i] != TYPE_INTEGER)
         {
            throw new SQLException(errUsage);
         }  
      }
      return TYPE_DATE;
   }

   public void setSpecialValue(int type, Object value)
   {
   }

   public Object getSpecialValue(int type)
   {
      return null;
   }

   public Object evaluate(Object[] parameters)
   {
      Calendar cal = Calendar.getInstance();
      cal.set(((Integer)parameters[0]).intValue(),
              ((Integer)parameters[1]).intValue() - 1,
              ((Integer)parameters[2]).intValue());
      return new Long(cal.getTime().getTime());
   }
}
