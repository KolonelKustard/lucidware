/*-----------------------------------------------------------------------------
 *
 * Enhydra InstantDB
 * The Initial Developer of the Original Code is Lutris Technologies Inc.
 * Portions created by Lutris are Copyright 1997-2000 Lutris Technologies Inc.
 * All Rights Reserved.
 *
 * The contents of this file are subject to the Enhydra Public License
 * Version 1.1 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 * www.enhydra.org/license/epl.html
 *
 * Software distributed under the License is distributed on an "ASIS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * -----------------------------------------------------------------------------
 * $Id: pow.java,v 1.3 2000/08/09 12:51:28 pete Exp $
 * -----------------------------------------------------------------------------
 */
package org.enhydra.instantdb.db;

import org.enhydra.instantdb.db.SqlFunction;
import java.sql.SQLException;

/**
 * To_date implements the expression function:
 *
 *	POW (numeric expr1, numeric expr2).
 */
class pow implements SqlFunction {
  String usage = "POW requires two numeric parameters";

	public int checkParameters (int[] parameterTypes) throws SQLException {
		int paramCount = parameterTypes.length;				// get number of parameters
		if (paramCount != 2) {								// check parameter count
			throw new SQLException (usage);
		} // if
		if (parameterTypes[0] == TYPE_STRING) {				// check allowed param types
			throw new SQLException (usage);
		} // if
		if (parameterTypes[1] == TYPE_STRING) {				// check allowed param types
			throw new SQLException (usage);
		} // if
		return TYPE_DOUBLE;									// our return type
	} // checkParameters

	public void setSpecialValue (int type, Object value) throws SQLException {
	} // setSpecialValue

	public Object getSpecialValue (int type) throws SQLException {
		return null;
	} // getSpecialValue


	public Object evaluate(Object[] parameters) throws SQLException {
		Number n1 = (Number)parameters[0];
		double d1 = n1.doubleValue();
		Number n2 = (Number)parameters[1];
		double d2 = n2.doubleValue();
		Double res = new Double (Math.pow(d1, d2));
		return res;
	} // evaluate


} // class pow
