/*-----------------------------------------------------------------------------
 *
 * Enhydra InstantDB
 * The Initial Developer of the Original Code is Lutris Technologies Inc.
 * Portions created by Lutris are Copyright 1997-2000 Lutris Technologies Inc.
 * All Rights Reserved.
 *
 * The contents of this file are subject to the Enhydra Public License
 * Version 1.1 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 * www.enhydra.org/license/epl.html
 *
 * Software distributed under the License is distributed on an "ASIS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * -----------------------------------------------------------------------------
 * $Id: datefixation.java,v 1.3 2000/08/09 12:51:27 pete Exp $
 * -----------------------------------------------------------------------------
 */
package org.enhydra.instantdb.db;

import org.enhydra.instantdb.db.SqlFunction;
import java.util.Date;
import java.util.*;
import java.sql.SQLException;

/**
 * This class is a SQL-function class which is used for InstantDB
 * to use in SQL.
 * Use to set the min,sec and millisec in timestamps/dates.
 * Example :
 *
 * a column 'logtime' with a entry '2000-feb-18 13:03:29'
 *
 * select datefixation (logtime,-1,-1,-1,-1,59,59,999) from table1
 *
 * gives '2000-feb-18 13:59:59:999' 
 *
 *
 *
 * 18/2/2000 Martin Husted, Electrolux Nyborg
 * 15/6/2000 Martin Husted Hartvig (martin.husted@notes.electrolux.dk): Small fix if parameters == null in public Object evaluate(Object[] parameters)
 */

public class datefixation implements SqlFunction{
  private String error = "datefixation (date,int(YEAR),int(MONTH),int(DAY_OF_MONTH),int(HOUR_OF_DAY),int(MINUTE),int(SEC),int(MILLISEC))";
  static Calendar calendar = new GregorianCalendar (TimeZone.getTimeZone ("GMT"));
  
  public int checkParameters(int[] parameterTypes) throws SQLException{
    if ((parameterTypes.length != 4)&&(parameterTypes[0] != SqlFunction.TYPE_DATE))
      throw new SQLException(error);

    for (int i = 1;i<8;i++)
      if (parameterTypes[i] != SqlFunction.TYPE_INTEGER)
        throw new SQLException(error);
  
    return SqlFunction.TYPE_DATE;
  }

  public void setSpecialValue(int type, Object value){
  }

  public Object getSpecialValue(int type){
    return null;
  }

  public Object evaluate(Object[] parameters){
    if (parameters==null)
      return null;
      
    java.util.Date time = new java.util.Date(((Long)parameters[0]).longValue());
    calendar.setTime(time);
                             
    if (((Integer)parameters[1]).intValue()!=-1)
      calendar.set(Calendar.YEAR,((Integer)parameters[1]).intValue());

    if (((Integer)parameters[2]).intValue()!=-1)
      calendar.set(Calendar.MONTH,((Integer)parameters[2]).intValue());

    if (((Integer)parameters[3]).intValue()!=-1)
      calendar.set(Calendar.DAY_OF_MONTH,((Integer)parameters[3]).intValue());

    if (((Integer)parameters[4]).intValue()!=-1)
      calendar.set(Calendar.HOUR_OF_DAY,((Integer)parameters[4]).intValue());

    if (((Integer)parameters[5]).intValue()!=-1)
      calendar.set(Calendar.MINUTE,((Integer)parameters[5]).intValue());
    
    if (((Integer)parameters[6]).intValue()!=-1)
      calendar.set(Calendar.SECOND,((Integer)parameters[6]).intValue());
    
    if (((Integer)parameters[7]).intValue()!=-1)
      calendar.set(Calendar.MILLISECOND,((Integer)parameters[7]).intValue());    
    
    return new java.sql.Timestamp((calendar.getTime()).getTime());
  }
}
