/*-----------------------------------------------------------------------------
 *
 * Enhydra InstantDB
 * The Initial Developer of the Original Code is Lutris Technologies Inc.
 * Portions created by Lutris are Copyright 1997-2000 Lutris Technologies Inc.
 * All Rights Reserved.
 *
 * The contents of this file are subject to the Enhydra Public License
 * Version 1.1 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 * www.enhydra.org/license/epl.html
 *
 * Software distributed under the License is distributed on an "ASIS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * -----------------------------------------------------------------------------
 * $Id: random.java,v 1.3 2000/08/09 12:51:28 pete Exp $
 * -----------------------------------------------------------------------------
 */
package org.enhydra.instantdb.db;

import org.enhydra.instantdb.db.SqlFunction;
import java.sql.SQLException;

/**
 * Implements the expression function:
 *
 *	RANDOM (numeric expr).
 */
class random implements SqlFunction {

	public int checkParameters (int[] parameterTypes) throws SQLException {
		int paramCount = parameterTypes.length;				// get number of parameters
		String usage = "RANDOM requires a single numeric parameter";
		if (paramCount != 1) {								// check parameter count
			throw new SQLException (usage);
		} // if
		if (parameterTypes[0] == TYPE_STRING) {				// check allowed param types
			throw new SQLException (usage);
		} // if
		return TYPE_INTEGER;								// our return type
	} // checkParameters 

	public void setSpecialValue (int type, Object value) throws SQLException {
	} // setSpecialValue

	public Object getSpecialValue (int type) throws SQLException {
		return null;
	} // getSpecialValue


	public Object evaluate(Object[] parameters) throws SQLException {
		Number n = (Number)parameters[0];
		double d = n.doubleValue();
		Double res = new Double (Math.random()*d);
		return res;
	} // evaluate


} // class random
