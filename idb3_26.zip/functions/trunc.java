/*-----------------------------------------------------------------------------
 *
 * Enhydra InstantDB
 * The Initial Developer of the Original Code is Lutris Technologies Inc.
 * Portions created by Lutris are Copyright 1997-2000 Lutris Technologies Inc.
 * All Rights Reserved.
 *
 * The contents of this file are subject to the Enhydra Public License
 * Version 1.1 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 * www.enhydra.org/license/epl.html
 *
 * Software distributed under the License is distributed on an "ASIS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * -----------------------------------------------------------------------------
 * $Id: trunc.java,v 1.3 2000/08/09 12:51:29 pete Exp $
 * -----------------------------------------------------------------------------
 */
package org.enhydra.instantdb.db;
import org.enhydra.instantdb.db.SqlFunction;
import java.sql.*;
import java.util.GregorianCalendar;

class trunc implements SqlFunction {
static final String truncs="YMDH";
static final int TRUNCHR =3;
static final int TRUNCDY =2;
static final int TRUNCMO =1;
static final int TRUNCYR =0;
class MyCalendar extends GregorianCalendar {
    public void setFromMillis(long millis) {
      setTimeInMillis(millis);
    } 
}
  public int checkParameters(int[] parameterTypes)
                    throws java.sql.SQLException {
     String usage="Requires a datetime or datetime and a string.";
     int numpar=parameterTypes.length;
     int retck = -1;
     if (numpar>0) {
       if (parameterTypes[0]==TYPE_DATE) {
         if (numpar==1) {
           retck=TYPE_DATE;
         } else {
           if(parameterTypes[1]==TYPE_STRING) {
            retck=TYPE_DATE;
           } else {
             usage="Second parameter is not string: "+TYPE_STRING+" its "+parameterTypes[1];
           }
         } // endif numpar==1
       } else {
          usage = "First parameter is not date: "+TYPE_DATE+" its "+parameterTypes[0];
       } // Endif TYPE_DATE
     } else {
       usage="no parameters given";
     } // endif numpar>0

     if (retck != TYPE_DATE) { throw new SQLException (usage); }
     return retck;
  } // End method.

 
  public Object evaluate(Object[] parameters) 
   throws java.sql.SQLException {
     Long llong = new Long(0);
     llong = (Long) parameters[0];
     long lval = llong.longValue();  
     Timestamp callobj=new Timestamp( lval);
     Timestamp retobj;
     Object retval;        
     if (parameters.length==2) {
           retobj= trunck(callobj, (String) parameters[1]);
           lval= retobj.getTime();
     }   
     if (parameters.length==1) {
           retobj = trunck(callobj);
           lval= retobj.getTime();
     }  

     Long rlong = new Long(lval);
     return (Object) rlong;
  }
  public Timestamp trunck (Timestamp instamp) {
  return trunck(instamp,"DD");
  }

 public Timestamp trunck (Timestamp instamp, String truncto) {

     long longtime=instamp.getTime();    
     MyCalendar cl = new MyCalendar();
     cl.setFromMillis(longtime); 

//    cl.set(instamp.getYear(), instamp.getMonth(), instamp.getDate(), instamp.getHours(),
//       instamp.getMinutes(), instamp.getSeconds());

    int truncx=truncs.indexOf(truncto.substring(0,1)); 

    // Note the absense of breaks: Heideger would say "the thing is thinging."
    switch (truncx) {
    case TRUNCYR: cl.set(cl.MONTH,0);		// Truncate to year (1st month).
    case TRUNCMO: cl.set(cl.DAY_OF_MONTH,1);	// Truncate to month (1st day). 
    case TRUNCDY: cl.set(cl.HOUR,0);            // Truncate to day (0 hour).
    case TRUNCHR: cl.set(cl.MINUTE,0);  		// Truncate to hour (0 minute, sec, and milli)   
       cl.set(cl.SECOND,0); 
       cl.set(cl.MILLISECOND,0);
      
    } // End switch.
    Timestamp retstamp= new Timestamp(cl.getTime().getTime());
    return retstamp;
 }
 public void setSpecialValue(int type,
                            java.lang.Object value)
                     throws java.sql.SQLException {

 }

 public java.lang.Object getSpecialValue(int type)
                                 throws java.sql.SQLException {
        Object o=null;
        return o;
 }

}