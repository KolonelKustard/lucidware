/*-----------------------------------------------------------------------------
 *
 * Enhydra InstantDB
 * The Initial Developer of the Original Code is Lutris Technologies Inc.
 * Portions created by Lutris are Copyright 1997-2000 Lutris Technologies Inc.
 * All Rights Reserved.
 *
 * The contents of this file are subject to the Enhydra Public License
 * Version 1.1 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 * www.enhydra.org/license/epl.html
 *
 * Software distributed under the License is distributed on an "ASIS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * -----------------------------------------------------------------------------
 * $Id: daysdiff.java,v 1.3 2000/08/09 12:51:27 pete Exp $
 * -----------------------------------------------------------------------------
 */
package org.enhydra.instantdb.db;

import org.enhydra.instantdb.db.SqlFunction;
import java.util.Date;
import java.util.Calendar;
import java.sql.SQLException;

/**
 * this class is a SQL-function class which is used for InstantDB
 * to use in SQL. It calculates the days between two dates
 * Use this class like this DAYSDIFF(Date, Date)
 */
public class daysdiff implements SqlFunction
{
   private String errUsage = "Error: use DAYSDIFF(Date, Date)";
   
   public int checkParameters(int[] parameterTypes) throws SQLException
   {
      if (parameterTypes.length != 2)
      {
         throw new SQLException(errUsage);
      }
      
      for (int i = 0; i < 2; i++)
      {
         if (parameterTypes[i] != SqlFunction.TYPE_DATE)
         {
            throw new SQLException(errUsage);
         }
      }
      return TYPE_INTEGER;
   }

   public void setSpecialValue(int type, Object value)
   {
   }

   public Object getSpecialValue(int type)
   {
      return null;
   }

   public Object evaluate(Object[] parameters)
   {
      long diff = ((Long)parameters[0]).longValue() - ((Long)parameters[1]).longValue();
      //                               sec    min hour day
      int days = Math.abs((int)(diff / 1000 / 60 / 60 / 24));
      
      return new Integer(days);
   }
}
