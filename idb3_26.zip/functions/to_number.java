/*-----------------------------------------------------------------------------
 *
 * Enhydra InstantDB
 * The Initial Developer of the Original Code is Lutris Technologies Inc.
 * Portions created by Lutris are Copyright 1997-2000 Lutris Technologies Inc.
 * All Rights Reserved.
 *
 * The contents of this file are subject to the Enhydra Public License
 * Version 1.1 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 * www.enhydra.org/license/epl.html
 *
 * Software distributed under the License is distributed on an "ASIS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * -----------------------------------------------------------------------------
 * $Id: to_number.java,v 1.3 2000/08/09 12:51:29 pete Exp $
 * -----------------------------------------------------------------------------
 */
package org.enhydra.instantdb.db;

import org.enhydra.instantdb.db.SqlFunction;
import java.sql.SQLException;
import java.util.*;

/**
 * To_date implements the expression function:
 *
 *	TO_NUMBER (date expr, selection).
 */
class to_number implements SqlFunction {

	public int checkParameters (int[] parameterTypes) throws SQLException {
		int paramCount = parameterTypes.length;				// get number of parameters
		String usage = "TO_NUMBER requires a date expression and a selection value as parameters";
		if (paramCount != 2) {								// check parameter count
			throw new SQLException (usage);
		} // if
		if ((parameterTypes[0] != TYPE_LONG) &&				// check allowed 1st param types
			(parameterTypes[0] != TYPE_DATE) &&
			(parameterTypes[0] != TYPE_STRING) ) {
			throw new SQLException (usage);
		} // if
		if (parameterTypes[1] != TYPE_INTEGER) {			// check allowed 2nd param types
			throw new SQLException (usage);
		} // if
		return TYPE_INTEGER;								// our return type
	} // checkParameters 

	int		milleniumBoundary;								// the cutoff for 21st century 2 digit years

	public void setSpecialValue (int type, Object value) throws SQLException {
		if (type == MILLENIUM_BOUNDARY) {					// if special value passed in is the millenium boundary
			milleniumBoundary = ((Integer)value).intValue();
		} // if
	} // setSpecialValue

	public Object getSpecialValue (int type) throws SQLException {
		if (type == DATE_FORMAT) {							// if InstantDB requesting date information
			return new Integer (1);							// tell it that 2nd parameter is the date format
		} // if
		return null;
	} // getSpecialValue


	public Object evaluate(Object[] parameters) throws SQLException {
		Object res = parameters[0];							// first expression can be out result
		if (parameters[0] instanceof String) {				// unless 1st parameter is a date string
			String dateString = (String)parameters[0];		// get date string
			res = DateColumn.toDate (null, dateString, milleniumBoundary, false);
		} // if
		Calendar cal = Calendar.getInstance();				// get a calendar object
		long l = ((Number)res).longValue();					// get the date
		java.util.Date d = new java.util.Date (l);			// turn into a date
		cal.setTime(d);										// set calendar with value
		int whatToGet = ((Number)parameters[1]).intValue();	// determine what to get
		int retInt=cal.get(whatToGet);						// return value as an int
		res = new Integer (retInt);							// set return value
		return res;
	} // evaluate


} // class to_number 
