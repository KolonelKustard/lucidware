/*-----------------------------------------------------------------------------
 *
 * Enhydra InstantDB
 * The Initial Developer of the Original Code is Lutris Technologies Inc.
 * Portions created by Lutris are Copyright 1997-2000 Lutris Technologies Inc.
 * All Rights Reserved.
 *
 * The contents of this file are subject to the Enhydra Public License
 * Version 1.1 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 * www.enhydra.org/license/epl.html
 *
 * Software distributed under the License is distributed on an "ASIS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * -----------------------------------------------------------------------------
 * $Id: concat.java,v 1.3 2000/08/09 12:51:27 pete Exp $
 * -----------------------------------------------------------------------------
 */
package org.enhydra.instantdb.db;
import org.enhydra.instantdb.db.SqlFunction;
import java.sql.*;

/**
  * <p>concat provides the equivalent of the standard SQL field concatenation logic.
  * Rather than writing select lastName + ', ' + firstName as fullName from users, <br>
  * use select concat(lastName, ', ', firstName) as fullName from users<br>
  */
class concat implements SqlFunction {

  /** <p>check that there is at least one parameter supplied 
    * @throws SQLException if no parameters are supplied
    * @returns TYPE of return from evaluate()
    */
  public int checkParameters(int[] parameterTypes) throws java.sql.SQLException {
     if (parameterTypes.length < 1) throw new SQLException("usage: concat(String, String, ...)");
     return TYPE_STRING;
  } 

  /** <p>Concatenate all concat input parameters into a single String 
    * @returns String consisting of concatenation of all parameters supplied to concat() function
    */
  public Object evaluate(Object[] parameters) {
     StringBuffer sb = new StringBuffer();
     for (int i = 0; i < parameters.length; i++)
		sb.append(parameters[i]);
     return sb.toString();
  }

 /** <p>Not used */
 public void setSpecialValue(int type, Object value) throws SQLException {
 }

 /** <p>Not used */
 public Object getSpecialValue(int type) throws SQLException {
        return null;
 }

}