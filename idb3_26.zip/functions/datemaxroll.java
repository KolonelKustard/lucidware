/*-----------------------------------------------------------------------------
 *
 * Enhydra InstantDB
 * The Initial Developer of the Original Code is Lutris Technologies Inc.
 * Portions created by Lutris are Copyright 1997-2000 Lutris Technologies Inc.
 * All Rights Reserved.
 *
 * The contents of this file are subject to the Enhydra Public License
 * Version 1.1 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 * www.enhydra.org/license/epl.html
 *
 * Software distributed under the License is distributed on an "ASIS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * -----------------------------------------------------------------------------
 * $Id: datemaxroll.java,v 1.3 2000/08/09 12:51:27 pete Exp $
 * -----------------------------------------------------------------------------
 */
package org.enhydra.instantdb.db;

import org.enhydra.instantdb.db.SqlFunction;
import java.util.Date;
import java.util.*;
import java.sql.SQLException;

/**
 * This class is a SQL-function class which is used for InstantDB
 * to use in SQL.
 * Use to "roll" timestamps/dates to a "local" maximum. This could be
 * Calendar.DAY_OF_YEAR,Calendar.DAY_OF_MONTH,Calendar.DAY_OF_WEEK,
 * Calendar.HOUR_OF_DAY,Calendar.MINUTE and -1 for roll to "now".
 *
 * Example :
 *
 * a column 'logtime' with a entry '2000-feb-18 13:03:29'
 *
 * select datemaxroll (logtime,Calendar.DAY_OF_YEAR) from table1 
 * gives '2000-dec-31 23:59:59:999' 
 *
 * select datemaxroll (logtime,Calendar.DAY_OF_MONTH) from table1 
 * gives '2000-feb-29 23:59:59:999' 
 *
 * select datemaxroll (logtime,Calendar.DAY_OF_WEEK) from table1 
 * gives '2000-feb-20 23:59:59:999'     NOTE: in EU last day of week is Sunday, 
 *                                            in US last day of week is Saturday.
 *
 * select datemaxroll (logtime,Calendar.HOUR_OF_DAY) from table1 
 * gives '2000-feb-18 23:59:59:999'
 *
 * select datemaxroll (logtime,Calendar.MINUTE) from table1 
 * gives '2000-feb-18 13:59:59:999'
 *
 * select datemaxroll (logtime,Calendar.SECOND) from table1 
 * gives '2000-feb-18 13:03:59:999'
 *
 *
 * Say that there is a second entry '2000-feb-22 17:33:19'
 * select datemaxroll (logtime,-1) from table1 
 * gives 
 * '2000-feb-29 12:03:53:697'
 * '2000-feb-29 12:03:53:697'
 *
 *
 *
 * note that java.util.Date.toString() uses your local TimeZone settings.
 *
 *
 * 29/2/2000 Martin Husted (martin.husted@notes.electrolux.dk), Electrolux Nyborg
 * 15/6/2000 Martin Husted Hartvig (martin.husted@notes.electrolux.dk): Small fix if parameters == null in public Object evaluate(Object[] parameters)
 */

public class datemaxroll implements SqlFunction{
  static GregorianCalendar calendar = new GregorianCalendar (TimeZone.getTimeZone ("GMT"),Locale.getDefault());
  static private java.util.Date fixTime;
  private int lastDayOfWeek;
  private String error = "datemaxroll (date,field). Field = {DAY_OF_YEAR|DAY_OF_MONTH|DAY_OF_WEEK|HOUR_OF_DAY|MINUTE|-1}";
  
  public datemaxroll(){
    calendar.setLenient(true);
    setLastDayOfWeek((calendar.getFirstDayOfWeek()+6)%7+7);
    setFixTime(calendar.getTime());
  }

  private int getLastDayOfWeek(){
    return lastDayOfWeek;  
  }

  private void setLastDayOfWeek(int lastDayOfWeek){
    this.lastDayOfWeek=lastDayOfWeek;
  }

  private java.util.Date getFixTime(){
    return fixTime;  
  }

  private void setFixTime(java.util.Date fixTime){
    this.fixTime=fixTime;
  }

  public int checkParameters(int[] parameterTypes) throws SQLException{
    if ((parameterTypes.length != 2)&&(parameterTypes[0] != SqlFunction.TYPE_DATE))
      throw new SQLException(error);

    for (int i = 1;i<2;i++)
      if (parameterTypes[i] != SqlFunction.TYPE_INTEGER)
        throw new SQLException(error);
  
    return SqlFunction.TYPE_DATE;
  }

  public void setSpecialValue(int type, Object value){
  }

  public Object getSpecialValue(int type){
    return null;
  }

  public Object evaluate(Object[] parameters){
    if (parameters==null)
      return null;

    java.util.Date time = new java.util.Date(((Long)parameters[0]).longValue());
    int field = ((Integer)parameters[1]).intValue();

    if (field == -1)
      calendar.setTime(getFixTime());      
    else{
      calendar.setTime(time);                               
  
      switch (field){
        case Calendar.DAY_OF_YEAR:
//          calendar.set(field,calendar.getActualMaximum(field));    
        case Calendar.DAY_OF_MONTH:
//          calendar.set(field,calendar.getActualMaximum(field));    
        case Calendar.DAY_OF_WEEK:
          if (field == Calendar.DAY_OF_WEEK) calendar.set(Calendar.DAY_OF_WEEK,getLastDayOfWeek());                            
        case Calendar.HOUR_OF_DAY:                            
          calendar.set(Calendar.HOUR_OF_DAY,23);                                    
        case Calendar.MINUTE:
          calendar.set(Calendar.MINUTE,59);                                    
        case Calendar.SECOND:
          calendar.set(Calendar.SECOND,59);                                    
          calendar.set(Calendar.MILLISECOND,999);                                    
          break;           
      }
    }
    
    return new java.sql.Timestamp((calendar.getTime()).getTime());
  }
}
