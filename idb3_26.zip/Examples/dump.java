/*-----------------------------------------------------------------------------
 *
 * Enhydra InstantDB
 * The Initial Developer of the Original Code is Lutris Technologies Inc.
 * Portions created by Lutris are Copyright 1997-2000 Lutris Technologies Inc.
 * All Rights Reserved.
 *
 * The contents of this file are subject to the Enhydra Public License
 * Version 1.1 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 * www.enhydra.org/license/epl.html
 *
 * Software distributed under the License is distributed on an "ASIS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * -----------------------------------------------------------------------------
 * $Id: dump.java,v 1.3 2000/08/09 12:51:24 pete Exp $
 * -----------------------------------------------------------------------------
 */
package org.enhydra.instantdb;

import java.io.*;

/**
 * Depending on input parameters does one of the following:
 *
 *	dump dbasename t			dumps the table list
 *	dump dbasename c tableID	dumps all columns for the given ID
 *	dump dbasename j			dumps the journal file
 *
 * You must be in the directory containing the required file
 * before running the command.
 */
class dump {

	static RandomAccessFile rndFile;
	static int rowCount;

	// Transaction Record types.

	final static int		TR_BEGIN=0x4265676e;
	final static int		TR_END=0x45656e5f;
	final static int		TR_INSERT=0x496e7274;
	final static int		TR_DELETE=0x44656c74;
	final static int		TR_INS_BLOB=0x49626c62;
	final static int		TR_DEL_BLOB=0x44626c62;
	final static int		TR_MARKER=0x5472616e;		// delimits transaction records
	final static int		TR_CHECKPOINT=0x4368656b;

	/**
	 * Checks the argument count
	 */
	static void checkArgs (int actual, int expected) {
		if (actual < expected) {							// must have at least dbname and command
			System.out.println ("Syntax: dump dbasename {t | c tableID | j}");
			System.exit(0);
		} // if
	} // method checkArgs

	/**
	 * Dumps table header information belonging to an integer column.
	 */
	static void dumpIntColStuff (String name) throws IOException {
		boolean autoInc = rndFile.readBoolean ();			// read the col's auto-inc flag
		int incVal = rndFile.readInt ();					// ...and it's auto-inc value
		System.out.println ("Column "+padString(name,12)+": autoInc = "+autoInc+" inc val = "+incVal);
	} // method dumpIntColStuff

	/**
	 * Dumps table header information belonging to a string column.
	 */
	static void dumpStringColStuff (String name) throws IOException {
		int maxSize = rndFile.readInt ();					// read max size of strings in this col
		System.out.println ("Column "+padString(name,12)+": max size = "+maxSize);
	} // method dumpStringColStuff

	/**
	 * Reads a string from the file.
	 */
	static String readString (int alloc) throws IOException {
		int size = rndFile.readInt();						// read size of string
		StringBuffer sb = new StringBuffer (size);			// create a variable string
		for (int i=0; i<size; i++) {						// for each character in the string
			sb.append(rndFile.readChar());					// add to the string
		} // for
		rndFile.skipBytes(2*(alloc-size));					// skip any padding (2 bytes per char)
		return sb.toString();
	} // method readString

	/**
	 * Pads a string with spaces.
	 */
	static String padString (String inStr, int len) {
		StringBuffer sb = new StringBuffer (inStr);			// create a variable string
		while (sb.length() < len) {							// while not long enough
			sb.append(' ');									// append a space
		} // while
		return sb.toString();
	} // method padString


	/**
	 * Dumps the header of a table.
	 */
	static void dumpHeader () throws IOException {
		if (rndFile.length() < 16) {						// if file too small to be valid
			throw new IOException ("Too short to be a Table file");
		} // if
		int majVer = rndFile.readInt ();					// read in the major version number
		int minVer = rndFile.readInt ();					// read minor version
		rowCount = rndFile.readInt ();						// rowCount
		int deletedRowCount = rndFile.readInt ();			// get the delRowCount
		System.out.println ("Created under version: "+majVer+"."+minVer);
		System.out.println (rowCount+" rows, of which "+deletedRowCount+" are deleted");
	} // method dumpHeader


	/**
	 * Dumps the tables table.
	 */
	static void dumpTables (String dbname) throws IOException {
		String filename = dbname+"$db$Tables.tbl";			// construct the filename
		rndFile = new RandomAccessFile (filename, "r");
		
		dumpHeader();
		dumpIntColStuff ("TableID");
		dumpStringColStuff ("TableName");
		dumpStringColStuff ("Path");
		dumpIntColStuff ("RecLen");

		int recLength = rndFile.readInt ();					// read int the length of each record
		System.out.println ("Record length in header is "+recLength);

		System.out.println ("row   control   ID  type reclen  name                 path ");
		int rownum=0;
		for (int i=0; i<rowCount; i++) {
			byte control = rndFile.readByte();
			int ID = rndFile.readInt();
			String name = readString(64);
			String path = readString(256);
			Integer reclen = new Integer (rndFile.readInt());
			String lenstr = padString(reclen.toString(),5);
			byte tabtype = rndFile.readByte();
			rownum++;
			String rowStr=padString((new Integer(rownum)).toString(),6);

			System.out.println (rowStr+"      "+control+" "+ID+"     "+tabtype+"   "+lenstr
				+" "+padString(name,20)+" "+path);
		} // for

		rndFile.close();
	} // method dumpTables

	/**
	 *
	 */
	static void dumpJournal (String dbname) throws IOException {
		String filename = dbname+".jrl";					// construct the filename
		rndFile = new RandomAccessFile (filename, "r");		// open the journal file 

		int majVer = rndFile.readInt ();					// read in the major version number
		int minVer = rndFile.readInt ();					// read minor version
		System.out.println ("Created under version: "+majVer+"."+minVer);
		long transnum = rndFile.readLong ();
		System.out.println ("Last Transaction number in header is: "+transnum);
		System.out.println ("ID    Size Type");

		int tablid,row;
		Integer colid;
		long offset;

		long nextRec = rndFile.length();					// start loop at end of last transaction record
		while (true) {										// keep rolling back
			if (nextRec <= 16) {							// if at start of file
				break;
			} // if
			rndFile.seek (nextRec-4);						// move count at end of transaction
			int transSize = rndFile.readInt();				// read the size
			String sizeStr=padString((new Integer(transSize)).toString(),5);
			nextRec = nextRec-transSize-4;					// calc where start of this rec is
			rndFile.seek (nextRec);							// move back to start of transaction record

			int marker = rndFile.readInt();					// read the marker
			if (marker != TR_MARKER) {						// check valid marker
				throw new IOException ("Internal error - could not read transaction marker at offset "
					+(rndFile.getFilePointer()-4));
			} // if
			Long id = new Long (rndFile.readLong());		// read the ID
			int type = rndFile.readInt(); 					// read the type

			System.out.print (padString(id.toString(),6)+sizeStr);
			switch (type) {									// depending on the type
			case TR_BEGIN:									// start found
				System.out.println ("Begin");
				break;
			case TR_CHECKPOINT:								// checkpoint found
				System.out.println ("Checkpoint");
				break;
			case TR_END:
				String[] stats={"Unknown","Commit","Rollback"};
				int stat = rndFile.readInt();				// read the commit status
				System.out.println ("End    Status="+stats[stat]);
				break;
			case TR_INSERT:									// INSERT row transaction
				tablid = rndFile.readInt();					// get table id
				row = rndFile.readInt();					// read row number
				System.out.println ("Insert TableID="+tablid+" row="+row);
				break;
			case TR_DELETE:									// DELETE row transaction
				tablid = rndFile.readInt();					// get table id
				row = rndFile.readInt();					// read row number
				byte noAutoInc = rndFile.readByte();		// read the auto-inc flag
				System.out.println ("Delete TableID="+tablid+" row="+row+" noAutoInc="+noAutoInc);
				break;
			case TR_INS_BLOB:								// blob inserted
				tablid = rndFile.readInt();					// get table id
				colid = new Integer (rndFile.readInt());	// get column id
				offset = rndFile.readLong();				// read offset
				System.out.println ("BlobIn TableID="+tablid+" colid="+colid+" offset="+offset);
				break;
			case TR_DEL_BLOB:								// blob deleted
				tablid = rndFile.readInt();					// get table id
				colid = new Integer (rndFile.readInt());	// get column id
				offset = rndFile.readLong();				// read offset
				System.out.println ("BlobDl TableID="+tablid+" colid="+colid+" offset="+offset);
				break;
			} // switch
		} // while
	} // method dumpJournal

	/**
	 *
	 */
	static void dumpColumn (String dbname, String tabid) throws IOException {
		String filename = dbname+"$db$Cols.tbl";			// construct the filename
		rndFile = new RandomAccessFile (filename, "r");
		int tableID = Integer.parseInt (tabid);				// convert to int
		
		dumpHeader();
		dumpIntColStuff ("ColID");
		dumpIntColStuff ("TableID");
		dumpStringColStuff ("ColName");
		dumpStringColStuff ("Flags");
		dumpIntColStuff ("Offset");
		dumpIntColStuff ("Length");
		dumpIntColStuff ("CacheAmnt");
		dumpStringColStuff ("ColDefault");

		int recLength = rndFile.readInt ();					// read int the length of each record
		System.out.println ("Record length in header is "+recLength);

		System.out.println ("row   control   ID  tabID type offset len CC CA   name"+
			"                 flags   default");
		int rownum=0;
		for (int i=0; i<rowCount; i++) {
			byte control = rndFile.readByte();
			int ID = rndFile.readInt();
			int tabID = rndFile.readInt();
			String name = readString(64);
			String flags = readString(64);
			byte coltype = rndFile.readByte();
			Integer offset = new Integer(rndFile.readInt());
			String offStr = padString (offset.toString(), 6);
			Integer len = new Integer(rndFile.readInt());
			String lenStr = padString (len.toString(),3);
			byte cacheCond = rndFile.readByte();
			Integer cachAmnt = new Integer (rndFile.readInt());
			String ca = padString (cachAmnt.toString(),4);
			String def = readString(64);
			rownum++;
			String rowStr=padString((new Integer(rownum)).toString(),6);

			if (tableID==tabID || tableID==0) {
				System.out.println (rowStr+"      "+control+" "+ID+"   "+tabID+"    "+coltype
					+"  "+offStr+lenStr+" "+cacheCond+"  "+ca+" "+padString(name,20)+" "+
					padString(flags,9)+" "+def);
			} // if
		} // for

		rndFile.close();
	} // method dumpColumn


	/**
	 * Program entry point
	 */
	public static void main (String[] args) {
		checkArgs (args.length, 2);							// must be at least 2 args
		try {
			if (args[1].equalsIgnoreCase("t")) {			// if a table dump requested
				dumpTables (args[0]);
			} else if (args[1].equalsIgnoreCase("j")) {		// if a journal dump
				dumpJournal (args[0]);
			} else if (args[1].equalsIgnoreCase("c")) {		// if a column dump
				checkArgs (args.length, 3);					// must be a third arg for this command
				dumpColumn (args[0], args[2]);
			} // if-else
		} catch (Exception e) {
			System.out.println (e.toString());
			e.printStackTrace();
		} // try-catch
	} // method main

} // class dump