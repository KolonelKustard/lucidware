

package org.enhydra.instantdb.SQLBuilder;

import java.util.*;

public class Res extends java.util.ListResourceBundle {
	static final Object[][] contents = {
	{ "Browse_Database", "Browse Database" },
	{ "jdbc_idb_", "jdbc:idb:" },
	{ "Connecting_", "Connecting..." },
	{ "Disconnect", "Disconnect" },
	{ "Connected_to", "Connected to " },
	{ "Error", "Error" },
	{ "org_enhydra_instantdb", "org.enhydra.instantdb.jdbc.idbDriver" },
	{ "sun_jdbc_odbc", "sun.jdbc.odbc.JdbcOdbcDriver" },
	{ "Driver", "Driver" },
	{ "URL", "URL" },
	{ "Username", "Username" },
	{ "Password", "Password" },
	{ "Browse", "Browse" },
	{ "Connect", "Connect" },
	{ "Disconnecting_", "Disconnecting..." },
	{ "Disconnected", "Disconnected" },
	{ "SELECT_FROM", "SELECT * FROM " },
	{ "FROM", " FROM " },
	{ "BLANK", " " },
	{ "Tables", "Tables" },
	{ "Columns", "Columns" },
	{ "Enter_row_limit_", "Enter row limit:" },
	{ "Submit", "Submit" },
	{ "Query_", "Query:" },
	{ "SELECT", "SELECT " },
	{ "KEY", "%" },
	{ "COLUMN_NAME", "COLUMN_NAME" },
	{ "Error_getting_columns", "Error getting columns" },
	{ "TABLE_NAME", "TABLE_NAME" },
	{ "Error_getting_tables", "Error getting tables" },
	{ "True", "True" },
	{ "False", "False" },
	{ "int", "int" },
	{ "boolean", "boolean" },
	{ "java_lang_String", "java.lang.String" },
	{ "Property", "Property" },
	{ "Value", "Value" },
	{ "Select_a_column", "Select a column" },
	{ "Error_setting_Results", "Error setting Results meta-data:\n" },
	{ "Could_not_load", "Could not load LookAndFeel: " },
	{ "Connection", "Connection" },
	{ "Connects_Disconnects", "Connects/Disconnects to a database" },
	{ "Dbase_Data", "Dbase Data" },
	{ "Database_Meta_data", "Database Meta-data" },
	{ "Query", "Query" },
	{ "Performs_database", "Performs database queries" },
	{ "Results_Data", "Results Data" },
	{ "Result_Set_Meta_data", "Result Set Meta-data" },
	{ "Enhydra_SQLBuilder", "Enhydra SQLBuilder" },
	{ "North", "North" },
	{ "Center", "Center" },
	{ "South", "South" },
	{ "Error_disconnecting_", "Error disconnecting: " }};

	public Object[][] getContents() {
		return contents;
	}
}