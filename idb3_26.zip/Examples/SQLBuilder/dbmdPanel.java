/*-----------------------------------------------------------------------------
 *
 * Enhydra InstantDB
 * The Initial Developer of the Original Code is Lutris Technologies Inc.
 * Portions created by Lutris are Copyright 1997-2000 Lutris Technologies Inc.
 * All Rights Reserved.
 *
 * The contents of this file are subject to the Enhydra Public License
 * Version 1.1 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 * www.enhydra.org/license/epl.html
 *
 * Software distributed under the License is distributed on an "ASIS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * -----------------------------------------------------------------------------
 * $Id: dbmdPanel.java,v 1.3 2000/08/09 12:51:24 pete Exp $
 * -----------------------------------------------------------------------------
 */
package org.enhydra.instantdb.SQLBuilder;

import java.awt.*;
import java.awt.event.*;
// -> jdk1.1 imports
// import com.sun.java.swing.*;
// import com.sun.java.swing.table.*;
// import com.sun.java.swing.event.*;
// -> jdk1.2 imports
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.event.*; 
import java.sql.*;
import java.lang.reflect.*;
import org.enhydra.instantdb.jdbc.*;

/**
 * Provides the tab showing the database meta-data
 */
class dbmdPanel extends JPanel {

	Connection		con;						// the database connection
	SQLBuilder		parent;						// the parent application
	JTable			outputTable;				// the table for outputting the results
	JScrollPane		scrollpane;					// the scroll pane containing the results table
	Statement		stmt;						// the statement used to make requests
	ResultSet		rs;							// the ResultSet from the last query
	DatabaseMetaData dbmd;						// the data we'll display



	/**
	 *
	 */
	dbmdPanel (SQLBuilder sb) {
		parent = sb;										// save parent application
		setLayout( new BorderLayout() );

		outputTable = new JTable();
		JScrollPane scrollpane = new JScrollPane(outputTable);
		add ( scrollpane, BorderLayout.CENTER );
	} // method dbmdPanel


	/**
	 * Invoked by ConnectionPanel when a database connect takes place.
	 */
	void onConnect (Connection c) {
		try {
			con = c;										// save the Connection
			dbmd = con.getMetaData();						// get the data to be displayed
			outputTable.setModel (new ReflectMetaData(dbmd));
		} catch (Exception e) {
		} // try-catch
	} // method onConnect


} // class dbmdPanel 