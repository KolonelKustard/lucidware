/*-----------------------------------------------------------------------------
 *
 * Enhydra InstantDB
 * The Initial Developer of the Original Code is Lutris Technologies Inc.
 * Portions created by Lutris are Copyright 1997-2000 Lutris Technologies Inc.
 * All Rights Reserved.
 *
 * The contents of this file are subject to the Enhydra Public License
 * Version 1.1 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 * www.enhydra.org/license/epl.html
 *
 * Software distributed under the License is distributed on an "ASIS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * -----------------------------------------------------------------------------
 * $Id: SQLBuilder.java,v 1.6 2000/12/19 11:33:39 pete Exp $
 * -----------------------------------------------------------------------------
 */
package org.enhydra.instantdb.SQLBuilder;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
// -> jdk1.1 imports
//import com.sun.java.swing.*;
// -> jdk1.2 imports
import javax.swing.*;
import java.util.*;


public class SQLBuilder extends JPanel {
    static JFrame frame;
	static ResourceBundle res;
	static SQLBuilder panel ;

	static final int WIDTH = 640;
	static final int HEIGHT = 520;

	JTabbedPane				tabs;				// the main tabbed panel
	JLabel					statusBar;			// the status bar
	ConnectionPanel			connectPanel;		// the panel that handles connections
	QueryPanel				qPanel;				// panel where queries are done
	dbmdPanel				dbmd;				// displays the database meta data
	rsmdPanel				rsmd;				// displays the ResultSet meta data
	String[]				landfNames;			// names of available look and feels
	String[]				landfClassNames;	// names of available look and feel classes
	JRadioButton[]			landfButtons;		// the look and feel buttons

	/**
	 *
	 */
	JRadioButton addButton (String label, ButtonGroup g, String command, ActionListener a) {
		JRadioButton b = new JRadioButton (label);
		b.setActionCommand (command);
		g.add (b);
		add(b);
		b.addActionListener (a);
		return b;
	} // method addButton

	/**
	 * Accessor for statusBar.
	 */
	JLabel getStatusBar () {
		return statusBar;
	} // method getStatusBar

	/**
	 * accessor for frame.
	 */
	JFrame getFrame () {
		return frame;
	} // method getFrame


	/**
	 * Invoked by the connection panel when a connection
	 * is made to the database.
	 */
	void onConnect (Connection c) {
		qPanel.onConnect (c);
		dbmd.onConnect(c);
	} // method onConnect

	/**
	 * Invoked by the query panel when a query completes.
	 */
	void onQuery (ResultSet r) {
		rsmd.onQuery (r);
	} // method onQuery


    public SQLBuilder() {
		// Create the buttons.
		ButtonGroup group = new ButtonGroup();
		RadioListener myListener = new RadioListener();
		statusBar = new JLabel (res.getString("Disconnected"));

		// find the available look and feels
		UIManager.LookAndFeelInfo[] lnfs = UIManager.getInstalledLookAndFeels();
		landfNames = new String[lnfs.length];
		landfClassNames = new String[lnfs.length];
		landfButtons = new JRadioButton[lnfs.length];
		for (int i=0; i<lnfs.length; i++) {
			landfNames[i] = lnfs[i].getName();
			landfClassNames[i] = lnfs[i].getClassName();
			landfButtons[i] = addButton (landfNames[i], group, landfClassNames[i], myListener);
		} // for

		tabs = new JTabbedPane ();
		connectPanel = new ConnectionPanel(this);
		dbmd = new dbmdPanel (this);
		qPanel = new QueryPanel(this);
		rsmd = new rsmdPanel (this);
		tabs.addTab (res.getString("Connection"),null,connectPanel,res.getString("Connects_Disconnects"));
		tabs.addTab (res.getString("Dbase_Data"),null,dbmd,res.getString("Database_Meta_data"));
		tabs.addTab (res.getString("Query"),null,qPanel,res.getString("Performs_database"));
		tabs.addTab (res.getString("Results_Data"),null,rsmd,res.getString("Result_Set_Meta_data"));

		tabs.setSelectedIndex(0);
    }


    /** An ActionListener that listens to the radio buttons. */
    class RadioListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			String lnfName = e.getActionCommand();
			try {
				UIManager.setLookAndFeel(lnfName);
				SwingUtilities.updateComponentTreeUI(frame);
				frame.setSize(WIDTH, HEIGHT);
				//frame.pack();
			} catch (Exception exc) {
				JRadioButton button = (JRadioButton)e.getSource();
				button.setEnabled(false);
				System.err.println(res.getString("Could_not_load") + lnfName);
			}
			updateState();
		} // actionPerformed
	} // class RadioListener 

    public void updateState() {
		String lnfName = UIManager.getLookAndFeel().getName();
		for (int i=0; i<landfClassNames.length; i++) {
			if (landfNames[i].equals(lnfName)) {
				landfButtons[i].setSelected(true);
				break;
			} // if
		} // for
    }



    public static void main(String s[]) {

		res = ResourceBundle.getBundle("org.enhydra.instantdb.SQLBuilder.Res");
		frame = new JFrame(res.getString("Enhydra_SQLBuilder"));
		panel = new SQLBuilder();
		
		frame.addWindowListener(new WindowEventHandler(panel));
		frame.getContentPane().add(res.getString("North"), panel);
		frame.getContentPane().add(res.getString("Center"), panel.tabs);
		frame.getContentPane().add(res.getString("South"), panel.statusBar);
		frame.setSize(WIDTH,HEIGHT);
		frame.setVisible(true);
		
		panel.updateState();
    }
}

class WindowEventHandler extends WindowAdapter {

	SQLBuilder	panel;
	ResourceBundle res = ResourceBundle.getBundle("org.enhydra.instantdb.SQLBuilder.Res");

	WindowEventHandler (SQLBuilder sqlbuild) {
		panel = sqlbuild;
	} // method WindowEventHandler

	public void windowClosing(WindowEvent e) {
		try {
			panel.connectPanel.onDisconnect();
		} catch (Exception ex) {
			System.out.println (res.getString("Error_disconnecting_")+ex.toString());
		} // try-catch
		System.exit(0);
	}
} // class WindowEventHandler 