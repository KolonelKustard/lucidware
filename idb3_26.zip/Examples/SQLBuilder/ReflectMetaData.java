/*-----------------------------------------------------------------------------
 *
 * Enhydra InstantDB
 * The Initial Developer of the Original Code is Lutris Technologies Inc.
 * Portions created by Lutris are Copyright 1997-2000 Lutris Technologies Inc.
 * All Rights Reserved.
 *
 * The contents of this file are subject to the Enhydra Public License
 * Version 1.1 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 * www.enhydra.org/license/epl.html
 *
 * Software distributed under the License is distributed on an "ASIS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * -----------------------------------------------------------------------------
 * $Id: ReflectMetaData.java,v 1.5 2000/11/30 12:50:48 pete Exp $
 * -----------------------------------------------------------------------------
 */
package org.enhydra.instantdb.SQLBuilder;

// -> jdk1.1 imports
// import com.sun.java.swing.*;
// import com.sun.java.swing.table.*;
// import com.sun.java.swing.event.*;
// -> jdk1.2 imports
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.event.*; 
import java.lang.reflect.*;
import java.util.ResourceBundle;

/**
 * Used to populate a met-data table.
 * Reflects all the supplied objects methods and then invokes upon request.
 */
class ReflectMetaData extends AbstractTableModel {

	String			blank = "";
	static ResourceBundle res = ResourceBundle.getBundle("org.enhydra.instantdb.SQLBuilder.Res");
	Method[]		mdMethods;					// the methods of the meta data class
	Object			metaData;					// the actual meta-data object
	Object[]		params;						// parameters to methods (if any)

	/**
	 * constructor
	 *
	 * Gets all the database meta data class methods
	 */
	 ReflectMetaData (Object o) {
		 super();
		 metaData = o;										// save the meta Data object
		 try {
			 Class mdClass = metaData.getClass();
			 mdMethods = mdClass.getDeclaredMethods();
		 } catch (Exception e) {
		 } // try-catch
	 } // method dbmdModel

	/**
	 * constructor
	 *
	 * Used to set method parameter
	 */
	 ReflectMetaData (Object o, int i) {
		 this (o);
		 params = new Object[1];							// create room for one parameter
		 params [0] = new Integer (i);						// and set to integer value
	 } // method dbmdModel



	public int getColumnCount() {return 2;}
	public int getRowCount() {return mdMethods.length;} 

	/**
	 *
	 */
	String toBoolStr (Boolean b) {
		String[] strs = {res.getString("True"),res.getString("False")};
		if (b.booleanValue())
			return strs[0];
		else
			return strs[1];
	} // method toBoolStr

	public Object getValueAt(int row, int col) { 
		try {
			if (col==0) return mdMethods[row].getName();

			Method curMethod = mdMethods[row];
			Class[] methodParams = curMethod.getParameterTypes();
			int paramCount = methodParams.length;

			// Check for a parameters
			Object[] theParams = null;
			if (paramCount > 1) return blank;
			if (paramCount == 1) {
				if (params==null) return blank;
				if (!methodParams[0].getName().equals(res.getString("int"))) return blank;
				theParams = params;
			} // if

			String returnType = curMethod.getReturnType().getName();
			if (returnType.equals(res.getString("boolean"))) {
				return toBoolStr ((Boolean)curMethod.invoke (metaData, theParams));
			} // if
			if (returnType.equals(res.getString("java_lang_String"))) {
				return curMethod.invoke (metaData, theParams);
			} // if
			if (returnType.equals(res.getString("int"))) {
				return curMethod.invoke (metaData, theParams);
			} // if
			return blank;
		} catch (Exception e) {
			System.out.println (e.toString());
			return blank;
		} // try-catch
	}

	public String getColumnName (int i) {
		if (i==0)
			return res.getString("Property");
		else
			return res.getString("Value");
	}
	
} // ReflectMetaData
