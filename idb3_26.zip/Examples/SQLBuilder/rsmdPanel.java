/*-----------------------------------------------------------------------------
 *
 * Enhydra InstantDB
 * The Initial Developer of the Original Code is Lutris Technologies Inc.
 * Portions created by Lutris are Copyright 1997-2000 Lutris Technologies Inc.
 * All Rights Reserved.
 *
 * The contents of this file are subject to the Enhydra Public License
 * Version 1.1 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 * www.enhydra.org/license/epl.html
 *
 * Software distributed under the License is distributed on an "ASIS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * -----------------------------------------------------------------------------
 * $Id: rsmdPanel.java,v 1.7 2000/11/30 12:50:48 pete Exp $
 * -----------------------------------------------------------------------------
 */
package org.enhydra.instantdb.SQLBuilder;

import java.awt.*;
import java.awt.event.*;
// -> jdk1.1 imports
// import com.sun.java.swing.*;
// import com.sun.java.swing.table.*;
// import com.sun.java.swing.event.*;
// -> jdk1.2 imports
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.event.*; 
import java.sql.*;
import java.lang.reflect.*;
import org.enhydra.instantdb.jdbc.*;
import java.util.*;

/**
 * Provides the tab showing the result set meta-data
 */
class rsmdPanel extends JPanel {

	Connection		con;						// the database connection
	ResourceBundle res = ResourceBundle.getBundle("org.enhydra.instantdb.SQLBuilder.Res");
	SQLBuilder		parent;						// the parent application
	JTable			outputTable;				// the table for outputting the results
	JScrollPane		scrollpane;					// the scroll pane containing the results table
	Statement		stmt;						// the statement used to make requests
	ResultSet		rs;							// the ResultSet from the last query
	ResultSetMetaData rsmd;						// the data we'll display
	JComboBox		columns;					// used to select a column for meta-data
	ReflectMetaData	dataModel;					// supplies data for the diaplyed table

	/**
	 *
	 */
	rsmdPanel (SQLBuilder sb) {

          super( new GridBagLayout() );

		parent = sb;										// save parent application

          GridBagConstraints gbc = new GridBagConstraints();
          gbc.fill = gbc.BOTH;
          gbc.insets = new Insets( 4,4,4,4 );

		// add the driver list box and label
          JLabel jlabel = new JLabel(res.getString("Select_a_column"), JLabel.RIGHT );
          add( jlabel, gbc );

          // create the columns drop down box
          columns = new JComboBox();
          gbc.weightx = 1.0;
          gbc.gridwidth = gbc.REMAINDER;
          add( columns, gbc );

          outputTable = new JTable();
          JScrollPane jscrollpane = new JScrollPane( outputTable );
          gbc.weightx = 0;
          gbc.weighty = 1.0;
          add( jscrollpane, gbc );

          columns.addActionListener( new theListener() );

	} // method rsmdPanel

	/**
	 *
	 */
	void onQuery (ResultSet r) {
		try {
			rs = r	;										// save the results set
			rsmd = rs.getMetaData();						// get the data to be displayed
               if ( columns.getItemCount() > 0 )
               {
     			columns.removeAllItems();						// clear out existing column list
               }
			for (int i=1; i<=rsmd.getColumnCount(); i++) {	// add each available column to list
				columns.addItem(rsmd.getColumnName(i));	
			} // for
		} catch (Exception e) {
			System.out.println (res.getString("Error_setting_Results") + e.toString());
		} // try-catch
	} // method onQuery

	/**
	 * Used to handle events
	 */
	class theListener implements ActionListener{

		public void actionPerformed (ActionEvent a) {
			try {
				if (a.getSource() == columns) {				// if a new column selected
					int selection = columns.getSelectedIndex();	// get currently selected table
					outputTable.setModel (
						new ReflectMetaData(rsmd,selection+1));// change data model
				} // if
			} catch (Exception e) {
				System.out.println (e.toString());
			} // try-catch
		} // method actionPerformed

	} // inner class ButtonListener 


} // class dbmdPanel 