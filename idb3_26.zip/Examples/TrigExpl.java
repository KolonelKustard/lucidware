/*-----------------------------------------------------------------------------
 *
 * Enhydra InstantDB
 * The Initial Developer of the Original Code is Lutris Technologies Inc.
 * Portions created by Lutris are Copyright 1997-2000 Lutris Technologies Inc.
 * All Rights Reserved.
 *
 * The contents of this file are subject to the Enhydra Public License
 * Version 1.1 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 * www.enhydra.org/license/epl.html
 *
 * Software distributed under the License is distributed on an "ASIS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * -----------------------------------------------------------------------------
 * $Id: TrigExpl.java,v 1.3 2000/08/09 12:51:24 pete Exp $
 * -----------------------------------------------------------------------------
 */
package org.enhydra.instantdb;

import org.enhydra.instantdb.jdbc.*;
import org.enhydra.instantdb.db.*;
import java.sql.*;
import java.util.Vector;

/**
 * <P>This class demonstrates the use of InstantDB triggers.
 *
 * <P>To view this source code best, use a wide screen editor
 * (132 columns or more) and set tabs to 4.
 */
class TrigExpl extends idbTrigger {

	static Connection		con;				// the database connection used throughout this example

	/**
	 * Creates a couple of tables and a couple of triggers. Then
	 * adds, deletes and modifies rows.
	 */
	public static void main (String args[]) {
		try {

			// First set up the JDBC driver

			Class.forName ("org.enhydra.instantdb.jdbc.idbDriver");				// load the InstantDB JDBC driver
			con = DriverManager.getConnection (				// get a connection to the sample database
				"jdbc:idb:sample.prp");
			Statement stmt = con.createStatement ();		// create a new statement

			// create the tables we need

			stmt.execute ("DROP TABLE employee");			// drop any existing employee table
			stmt.execute ("CREATE TABLE employee ("			// ...and create the new one
				+"emplID int AUTO INCREMENT, "
				+"name CHAR(40), "
				+"salary CURRENCY, "
				+"hired DATE, "
				+"age FLOAT, "
				+"comment BINARY)");
			stmt.execute ("DROP TABLE summary");			// drop any existing summary table
			stmt.execute ("CREATE TABLE summary ("			// ...and create the new one
				+"under20000 int, "
				+"over20000 int, "
				+"employeeCount int)");
			stmt.execute ("INSERT INTO summary VALUES (0,0,0)");// single row in summary table

			// create the triggers

			TrigExpl trig1 = new TrigExpl ("employee", 		// this trigger watches row adds and deletes
				idbTrigger.TRIGGER_ON_ADD+
				idbTrigger.TRIGGER_ON_DELETE);
			TrigExpl trig2 = new TrigExpl ("summary", 		// watches row updates and transactions
				idbTrigger.TRIGGER_ON_UPDATE+
				idbTrigger.TRIGGER_ON_COMMIT+
				idbTrigger.TRIGGER_ON_ROLLBACK);

			// Now start adding and modifying rows in employee.
			// The triggers will make changes to summary.

			stmt.execute ("INSERT INTO employee VALUES("
				+"0,'Fred Flintstone', '$19000.00', '1 Jan 1998', "
				+"32.0, 'a character from a different age')");
			stmt.execute ("INSERT INTO employee VALUES("
				+"0,'Barny Rubble', '$21000.00', '2 Jan 1998', "
				+"31.5, 'sometimes a bit slow')");
			stmt.execute ("INSERT INTO employee VALUES("
				+"0,'Wilma Flintstone', '$23000.00', '3 Jan 1998', "
				+"27.5, 'the sensible one')");
			try {
				// onUpdate has been set up to reject this
				stmt.execute ("INSERT INTO employee VALUES("
					+"0,'Bugs Bunny', '$23000.00', '3 Jan 1998', "
					+"27.5, 'in every cartoon')");
			} catch (Exception ex) {
				System.out.println (ex.toString());
				printSummary(stmt);
			} // try-catch
			stmt.execute ("DELETE FROM employee WHERE name='Wilma Flintstone'");
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		} // try-catch
	} // method main

	/**
	 * Our trigger constructor simply calls the idbTrigger constructor.
	 */
	TrigExpl (String table, int events) throws SQLException {
		super (table, events);
	} // method TrigExpl

	/**
	 *
	 */
	public void onAdd (Vector row, long transID) throws SQLException {

		Connection c = getConnection();
		java.util.Properties p = ((idbConnection)c).getProperties();
		System.out.println ("props="+p);

		// Extract the various fields using the trigger type mapping rules.

		Integer id = (Integer)row.elementAt(0);
		String Name = (String)row.elementAt(1);
		Long salary = (Long)row.elementAt(2);
		Long hired = (Long)row.elementAt(3);
		Float age = (Float)row.elementAt(4);
		byte[] blob = (byte[])row.elementAt(5);

		// The first byte of blobs is a type flag, so ignore it.
		String blobString = BlobColumn.blobToString (row.elementAt(5));

		System.out.println (id+" "+Name+" "+blobString
			+"\n"+transID+" Added to table "+getTableName());

		Statement s = con.createStatement ();					// create a new statement

		s.execute ("UPDATE summary SET employeeCount=employeeCount+1");

		if (salary.longValue() <= 2000000) {
			s.execute ("UPDATE summary SET under20000=under20000+1");
		} else {
			s.execute ("UPDATE summary SET over20000=over20000+1");
		} // if-else

		printSummary(s);
		
	} // method onAdd

	/**
	 *
	 */
	public void onDelete (Vector row, long transID) throws SQLException {

		// Extract the various fields using the trigger type mapping rules.

		Integer id = (Integer)row.elementAt(0);
		String Name = (String)row.elementAt(1);
		Long salary = (Long)row.elementAt(2);
		Long hired = (Long)row.elementAt(3);
		Float age = (Float)row.elementAt(4);
		byte[] blob = (byte[])row.elementAt(5);

		// The first byte of blobs is a type flag, so ignore it.
		String blobString = new String (blob,0,1,blob.length-1);

		System.out.println (transID+" "+Name+" Deleted from table "+getTableName());

		Statement s = con.createStatement ();					// create a new statement

		s.execute ("UPDATE summary SET employeeCount=employeeCount-1");

		if (salary.longValue() <= 2000000) {
			s.execute ("UPDATE summary SET under20000=under20000-1");
		} else {
			s.execute ("UPDATE summary SET over20000=over20000-1");
		} // if-else

		printSummary(s);

	} // method onDelete

	/**
	 *
	 */
	static void printSummary (Statement s) throws SQLException {
		s.execute("SELECT * FROM summary");
		ResultSet rs = s.getResultSet();
		rs.next();
		System.out.println("summary="+rs.getString(1)+","+rs.getString(2)+","+rs.getString(3));
	} // method printSummary

	/**
	 *
	 */
	public void onUpdate (Vector row, long transID) throws SQLException {
		Integer under20000 = (Integer)row.elementAt(0);
		Integer over20000 = (Integer)row.elementAt(1);
		Integer count = (Integer)row.elementAt(2);

		if (count.intValue()==4) {
			// 4th employee will be rejected
			throw new SQLException ("Not in this one bugs");
		} // if

		System.out.println (transID+" "+getTableName()+" updated "+under20000+" "+over20000+" "+count);
	} // method onUpdate

	/**
	 *
	 */
	public void preUpdate (Vector row, long transID) throws SQLException {
		Integer under20000 = (Integer)row.elementAt(0);
		Integer over20000 = (Integer)row.elementAt(1);
		Integer count = (Integer)row.elementAt(2);

		System.out.println (transID+" "+getTableName()+" before update "+under20000+" "+over20000+" "+count);
	} // method preUpdate

	/**
	 *
	 */
	public void onCommit (long transID) {
		System.out.println (transID+" committed");
	} // method onCommit

	/**
	 *
	 */
	public void onRollback (long transID) {
		System.out.println (transID+" rolled back");
	} // method onRollback

} // class TrigExpl