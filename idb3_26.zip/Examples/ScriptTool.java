/*-----------------------------------------------------------------------------
 *
 * Enhydra InstantDB
 * The Initial Developer of the Original Code is Lutris Technologies Inc.
 * Portions created by Lutris are Copyright 1997-2000 Lutris Technologies Inc.
 * All Rights Reserved.
 *
 * The contents of this file are subject to the Enhydra Public License
 * Version 1.1 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 * www.enhydra.org/license/epl.html
 *
 * Software distributed under the License is distributed on an "ASIS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * -----------------------------------------------------------------------------
 * $Id: ScriptTool.java,v 1.8 2001/01/13 14:17:52 pete Exp $
 * -----------------------------------------------------------------------------
 */

//
// Provides a sample of how to use InstantDB by implementing
// a simple scripting language.
//
// This code is best viewed in 132 columns, nowrap, tabs=8.
package org.enhydra.instantdb;


import java.net.URL;
import java.sql.*;
import java.io.*;
import java.util.*;
import org.enhydra.instantdb.db.Trace;
import org.enhydra.instantdb.db.utils;
import org.enhydra.instantdb.jdbc.*;

public class ScriptTool  {

	public static void main (String args[]) {

		try {

			// uncomment next line to enable DriverManager logging
			// java.sql.DriverManager.setLogStream(java.lang.System.out);

			// Regression tests assume UK date/time formatting.
			// Remove next line for US.

			Locale.setDefault (Locale.UK);

			// Create initial thread object to execute SQL from a file.
			String sqlfile = "sql1.txt";
			if (args.length > 0) {
				sqlfile = args[0];
			} // if

			Thread thread1 = new Thread (new SampleThread (sqlfile));

			// start the thread running
			thread1.start();

			// Wait for it to complete 
			thread1.join();
		}
		catch (Exception ex) {
			ex.printStackTrace ();
		}
	}
} // class sample

class SampleThread implements Runnable {
	
	Connection			con;
	BufferedReader		in;
	Statement			stmt;
	PreparedStatement	pstmt;
	ResultSet			rs;
	DatabaseMetaData	dma;
	Vector				childThreads;
	String				url;
	static PreparedStatement globPrepStmnt;
	static Connection	globCon;
	String				sqlName;
	char				command;
	String				sql;
	StringBuffer		curStatement;
	boolean				norsClose;				// true => don't close result sets
	TestObject			test1;					// used to test saving objects
	boolean				batchMode;				// true when statements are being batched together
	boolean				rsmd;					// true = result set meta data gets dumped after queries

	/**
	 * Each thread has its own set of SQL commands and its
	 * own statement objects. They share the same connection 
	 * though. They could equally well use different connections.
	 */
	public SampleThread (String fileName) {
		try {

			// Open the sample sql file. Opening it as a resource allows the file
			// to be picked up from jar files.

			FileReader fr = new FileReader (fileName);
			in = new BufferedReader (fr);
//			InputStream is = getClass().getResourceAsStream(fileName );
//			in = new BufferedReader(new InputStreamReader( is ));
			childThreads = new Vector (10,10);
			sqlName=fileName;
		} catch (Exception e) {
			e.printStackTrace ();
		} // try-catch
	} // method SampleThread

	/**
	 * Waits for all child threads to complete before continuing.
	 */
	void waitForChildren () throws InterruptedException {
		// wait for child threads to finish
		for (int i=0; i<childThreads.size(); i++) {
			Thread curThread = (Thread)childThreads.elementAt(i);
			curThread.join();
		} // for
	} // method waitForChildren


	/**
	 * Closes any current result set.
	 */
	 void closers () throws SQLException {
		if (norsClose) return;								// ignore if result sets to stay open
		if (rs == null) return;								// check for no results set
		if (rsmd) {											// if result set meta data is to be dumped
			ResultSetMetaData rsmd = rs.getMetaData ();		// get the meta data
			int numCols = rsmd.getColumnCount ();			// get number of columns in results set

			StringBuffer lineOut = new StringBuffer (64);	// used to buffer string output
			Trace.traceOut ("Result Set Meta Data");
			for (int i=1; i<=numCols; i++) {				// for each column
				String colName = rsmd.getColumnName (i);	// get next columns name
				String tabName = rsmd.getTableName (i);		// get next columns name
				lineOut.setLength(0);						// truncate the output string
				lineOut.append ("Table='"+tabName+"' ");	// start with column name
				lineOut.append (colName+": ");				// start with column name
				if (rsmd.isAutoIncrement(i)) {				// test for auto inc
					lineOut.append ("[AUTO INC] ");
				} // if
				if (rsmd.isCaseSensitive(i)) {				// test for case sensitive
					lineOut.append ("[CASE SENSITIVE] ");
				} // if
				if (rsmd.isCurrency(i)) {					// test for currency
					lineOut.append ("[CURRENCY] ");
				} // if
				if (rsmd.isNullable(i)==
					ResultSetMetaData.columnNullable) {		// test for nullable
					lineOut.append ("[NULLABLE] ");
				} // if
				if (rsmd.isReadOnly(i)) {					// test for read only
					lineOut.append ("[READONLY] ");
				} // if
				Trace.traceOut (lineOut.toString());
			} // for
		} // if
		try {
			rs.close();
		} catch (Exception e) {
			// may already be closed - just ignore
		} // try-catch
	 } // method closers



	/**
	 * Gets the next line of SQL from the file. Sets the global char
	 * <B>command</B> and the global String <B>sql</B>
	 */
	void getSQL (String loopStatement) throws IOException {
		if (loopStatement==null) {
			curStatement.setLength(0);
			boolean endFound=false;
			while (!endFound) {
				if (!in.ready()) {
					break;
				} // if
				String curLine = in.readLine();
				if (curLine == null) continue;
				if (curLine.length()==0) continue;
				curLine = curLine.trim();
				if (curLine.charAt(0)==';' ||
					curLine.charAt(0)=='!' ||
					curLine.charAt(0)=='-' ||
					curLine.charAt(0)=='/' ||
					curLine.charAt(0)=='#' ) 
					continue;
				if (curStatement.length()>0) {
					// We're concatinating lines. Treet EOL as a space.
					curStatement.append (' ');
				} // if
				curStatement.append(curLine);
				if (curStatement.charAt(curStatement.length()-1)==';') {
					endFound=true;
					// remove the trailing ;
					curStatement.setLength(curStatement.length()-1);
				} // if
			} // while
			sql = curStatement.toString();
		} else {
			sql = loopStatement;
		} // if-else

		// Got a full line, find out what it wants us to do

		sql=sql.trim();
		if (sql.length() > 0) {
			command = sql.charAt(0);
			if (sql.length() > 1) {
				if (sql.charAt(1) != ' ') {
					// no command given - default to 'e'
					command = 'e';
					sql = "  "+sql;
				} // if
			} // if
		} // if
	} // method getSQL


	/**
	 * This routine does the work of this particular thread.
	 */
	public void run () {
		Thread thisThread = Thread.currentThread();
		thisThread.setName(sqlName);
		long startTime=0;
		long diffTime=0;
		boolean gettingRepeatEntries=false;					// true when we're scanning a "repeat N" loop
		int repeatCount=0;									// non-zero when in repeat loop
		String[] repeatSQL = new String [100];				// can hold up to 100 statements
		int nextRepeatSQL=0;								// next available/executable repeatSQL entry
		curStatement = new StringBuffer (512);				// create the buffer that builds up the sql command

		// outer try block to handle IO errors etc
		try {
			while (in.ready()) {

				// read in lines until we get one terminated with a semi-colon

				if (repeatCount > 0) {						// if we're looping
					if (gettingRepeatEntries) {				// if still collecting entries
						getSQL(null);						// fetch next SQL statement from file
						repeatSQL [nextRepeatSQL++] = sql;	// save
						if (command=='}') {					// if end of loop
							gettingRepeatEntries = false;	// stop collecting SQL
							nextRepeatSQL=0;				// loop from first statement
						} // if
						continue;							// get next statement
					} else {
						getSQL(repeatSQL [nextRepeatSQL++]);// get next saved statement
						if (command=='}') {					// if end of loop
							nextRepeatSQL=0;				// loop from first statement
							repeatCount--;					// one more loop completed
							continue;						// back to start
						} // if
					} // if-else
				} else {
					getSQL(null);							// fetch next SQL statement from file
					if (sql.length()==0) {					// if there's nothing left to do
						break;								// stop trying to fetch sql
					} // if
				} // if-else

				try {
					sql=sql.substring(2);
					sql=sql.trim();
				} catch (Exception e) {
					sql = "";
				} // try-catch


				// Inner try block prevent SQL exceptions taking us out of the while loop
				try {
					StringTokenizer tokens = new StringTokenizer (sql);
					String token = null;
					startTime = System.currentTimeMillis();
					switch (command) {
					case 'c':
						// special command
						if (sql.equalsIgnoreCase("autocommit on")) {
							con.setAutoCommit (true);
							System.out.println ("Auto-commit is "+con.getAutoCommit());
						} else if (sql.equalsIgnoreCase("autocommit off")) {
							con.setAutoCommit (false);
							System.out.println ("Auto-commit is "+con.getAutoCommit());
						} else if (sql.equalsIgnoreCase("break")) {
							// Using a 'b' command in a script and setting a breakpoint
							// below, allows us to step through the next statement.
							System.out.println ("Breakpoint reached");
						} else if (sql.equalsIgnoreCase("batch mode")) {
							// starts batching sql statements
							batchMode = true;
						} else if (sql.equalsIgnoreCase("use global prepared statement")) {
							// Use the global prepared statement set up by another thread.
							pstmt = globPrepStmnt;
							break;
						} else if (sql.equalsIgnoreCase("cancel row updates")) {
							rs.cancelRowUpdates();
							break;
						} else if (sql.equalsIgnoreCase("create test object")) {
							test1 = new TestObject (1, "first test", null);
							test1 = new TestObject (2, "second test", test1);
							break;
						} else if (sql.equalsIgnoreCase("delete row")) {
							rs.deleteRow();
							break;
						} else if (sql.equalsIgnoreCase("execute batch")) {
							if (stmt != null) stmt.executeBatch();
							if (pstmt != null) pstmt.executeBatch();
							batchMode=false;
							break;
						} else if (sql.equalsIgnoreCase("export all")) {
							exportAll();
						} else if (sql.equalsIgnoreCase("import all")) {
							importAll();
						} else if (sql.equalsIgnoreCase("insert row")) {
							rs.insertRow();
							break;
						} else if (sql.equalsIgnoreCase("time")) {
							System.out.println ("Last command took: "+diffTime);
							break;
						} else if (sql.equalsIgnoreCase("set global prepared statement")) {
							// Save ine the static statement handle.
							// This allows other threads to access the statement.
							globPrepStmnt = pstmt ;
							break;
						} else if (sql.equalsIgnoreCase("use global connection")) {
							// Use the global prepared statement set up by another thread.
							con = globCon;
							stmt = con.createStatement ();
							break;
						} else if (sql.equalsIgnoreCase("set global connection")) {
							// Set the global connection so that other threads can use it
							globCon = con;
							break;
						} else if (sql.equalsIgnoreCase("update row")) {
							rs.updateRow();
							break;
						} else if (sql.equalsIgnoreCase("close")) {
							// close the database
							if (stmt != null) stmt.close();
							stmt = null;
							con.close();
							con=null;
							break;
						} else if (sql.equalsIgnoreCase("rollback")) {
							con.rollback();
						} else if (sql.equalsIgnoreCase("commit")) {
							con.commit();
						} else if (sql.equalsIgnoreCase("show meta-data")) {
							// get metadata
							rs = dma.getTypeInfo();
							dispResultSet (rs);
							rs.close();
							rs = dma.getTables("","","%",null);
							dispResultSet (rs);
							rs.close();
						} else if (sql.equalsIgnoreCase("system tables")) {
							String[] st = {"SYSTEM TABLE"};
							rs = dma.getTables("","","%",st);
							dispResultSet (rs);
							rs.close();
						} else if (sql.equalsIgnoreCase("ordinary tables")) {
							String[] st = {"TABLE"};
							rs = dma.getTables("","","%",st);
							dispResultSet (rs);
							rs.close();
						} else if (sql.equalsIgnoreCase("all tables")) {
							String[] st = {"SYSTEM TABLE", "TABLE"};
							rs = dma.getTables("","","%",st);
							dispResultSet (rs);
							rs.close();
						} else if (sql.equalsIgnoreCase("table types")) {
							rs = dma.getTableTypes ();
							dispResultSet (rs);
							rs.close();
						} else if (sql.equalsIgnoreCase("toggle result set close")) {
							norsClose = !norsClose;			// switch RS closing on/off
							if (!norsClose) {				// if closing switched back on
								closers();					// close any existing RS
							} // if
						} else if (sql.equalsIgnoreCase("toggle RSMD")) {
							// toggles RSMD dumps after queries
							rsmd = !rsmd;
						} else if (sql.equalsIgnoreCase("wait for children")) {
							// wait for child threads to complete
							waitForChildren();
						} else if (sql.equalsIgnoreCase("exit")) {
							// exit immediately

							System.exit(0);
						} else {
							String command = tokens.nextToken ();
							if (command.equalsIgnoreCase ("set")) {
								String setWhat = tokens.nextToken ();
								if (setWhat.equalsIgnoreCase ("timeout")) {
									int timeout = Integer.parseInt (tokens.nextToken ());
									stmt.setQueryTimeout (timeout);
								} else if (setWhat.equalsIgnoreCase ("maxRows")) {
									int max = Integer.parseInt (tokens.nextToken ());
									stmt.setMaxRows (max);
								} else if (setWhat.equalsIgnoreCase("isolation")) {
									String isolationLevel = tokens.nextToken ();
									if (isolationLevel.equalsIgnoreCase("READ_UNCOMMITTED")) {
										con.setTransactionIsolation (
											Connection.TRANSACTION_READ_UNCOMMITTED);
									} else if (isolationLevel.equalsIgnoreCase("SERIALIZABLE")) {
										con.setTransactionIsolation (
											Connection.TRANSACTION_SERIALIZABLE);
									} else if (isolationLevel.equalsIgnoreCase("READ_COMMITTED")) {
										con.setTransactionIsolation (
											Connection.TRANSACTION_READ_COMMITTED);
									} else if (isolationLevel.equalsIgnoreCase("REPEATABLE_READ")) {
										con.setTransactionIsolation (
											Connection.TRANSACTION_REPEATABLE_READ);
									} else {
										System.out.println ("Unknown set isolation level: "+isolationLevel);
									} // if-else
								} else {
									System.out.println ("Unknown set command: "+setWhat);
								} // if-else
							} else if (command.equalsIgnoreCase ("get")) {
								String getWhat = tokens.nextToken ();
								if (getWhat.equalsIgnoreCase ("columns")) {
									String tablePattern = tokens.nextToken ();
									String colPattern = tokens.nextToken ();
									rs = dma.getColumns("","",tablePattern,colPattern);
									dispResultSet (rs);
									rs.close();
								} else if (getWhat.equalsIgnoreCase ("imported_keys")){
									String table = tokens.nextToken ();
									rs = dma.getImportedKeys (null, null, table);
									dispResultSet (rs);
									rs.close();
								} else if (getWhat.equalsIgnoreCase ("exported_keys")){
									String table = tokens.nextToken ();
									rs = dma.getExportedKeys (null, null, table);
									dispResultSet (rs);
									rs.close();
								} else if (getWhat.equalsIgnoreCase ("crossReference")){
									String ptable = tokens.nextToken ();
									String ftable = tokens.nextToken ();
									rs = dma.getCrossReference (null, null, ptable, null, null, ftable);
									dispResultSet (rs);
									rs.close();
								} else {
									System.out.println ("Unknown get command: "+getWhat);
								} // if-else
							} else if (command.equalsIgnoreCase("sleep")) {
								int interval = Integer.parseInt (tokens.nextToken ());
								Thread.sleep (interval);
							} else {
								System.out.println ("Unknown command: "+command);
							} // if-else
						} // if-else
						break;
					case 'd':
						// load a driver
						Class.forName(sql).newInstance();
						
						break;
					case 'e':
						// execute command with no results set
						if (batchMode) {					// if in batch mode
							stmt.addBatch (sql);
						} else {
							stmt.executeUpdate (sql);
							rs = stmt.getResultSet();
							closers();
						} // if-else
						break;
					case 'i':
						// get index info for table
						rs = dma.getIndexInfo (null,null,sql,false,false);
						dispResultSet (rs);
						rs  = dma.getPrimaryKeys (null,null,sql);
						dispResultSet (rs);
						rs.close();
						break;
					case 'l':
						// last value inserted
						String tableName = tokens.nextToken ();
						String colName = tokens.nextToken ();
						idbConnection idbcon = (idbConnection)con;
						Trace.traceOut ("Table: "+tableName+", column: "+colName+", value inserted="
							+idbcon.getLastValueInserted(tableName, colName));
						break;
					case 'm':
						// move to a given row
						char moveType = tokens.nextToken().charAt(0);// get type of movement
						int rowNum = 0;							// will be used to posn cursor
						try {
							token = tokens.nextToken();			// get next token
							rowNum = Integer.parseInt (token);	// convert to int
						} catch (Exception e) {
						} // try-catch

						boolean result = false;				// used to keep result of move
						switch (moveType) {
						case 'a':							// absolute row
							result = rs.absolute (rowNum);
							break;
						case 'r':							// relative row
							result = rs.relative (rowNum);
							break;
						case 'n':							// next
							result = rs.next();
							break;
						case 'p':							// previous
							result = rs.previous();
							break;
						case 'f':							// first
							result = rs.first();
							break;
						case 'l':							// last
							result = rs.last();
							break;
						case 'b':							// before first
							rs.beforeFirst();
							break;
						case 't':							// after last
							rs.afterLast();
							break;
						case 'i':							// insert row
							rs.moveToInsertRow();
							break;
						case 'c':							// back to current row
							rs.moveToCurrentRow();
							break;
						} // switch
						Trace.traceOut (
							"result="+result+
							" row="+rs.getRow()+
							" beforeFirst="+rs.isBeforeFirst()+
							" afterLast="+rs.isAfterLast()+
							" first="+rs.isFirst()+
							" last="+rs.isLast());
						Trace.traceOut (dispRow(rs));

						break;
					case 'o':
						// get url to open
						String url = tokens.nextToken();

						// read in properties to pass to connection (optional)
						Properties props = new Properties();
						String username=null;				// default to no username and password
						String password= null;
						if (tokens.hasMoreTokens()) {
							username = tokens.nextToken();	// assume next string is username
						} // if
						if (tokens.hasMoreTokens()) {
							password = tokens.nextToken();	// assume next token is password
						} // if
						if (username != null) {				// if a username was found
							if (password != null) {			// ...and a password was found
								con = DriverManager.getConnection (url, username, password);
							} else {						// no password
								// assume "username" is the name of a props file to load
								FileInputStream propsStream = new FileInputStream (username);
								props.load (propsStream);
								propsStream.close();
								con = DriverManager.getConnection (url, props);
							} // if-else
						} else {							// no username or password
							con = DriverManager.getConnection (url);
						} // if-else


						// Get the DatabaseMetaData object and display
						// some information about the connection

						dma = con.getMetaData ();

						System.out.println("\nConnected to " + dma.getURL());
						System.out.println("Driver   " + dma.getDriverName());
						System.out.println("Version  " + dma.getDriverVersion());
						System.out.println("");

						// Create a Statement object so we can submit
						// SQL statements to the driver

						stmt = con.createStatement ();
						stmt.setQueryTimeout (300);

						// Have a prepared statment reference handy

						pstmt = null;
						
						break;
					case 'p':
						// prepared statement
						pstmt = con.prepareStatement (sql);
						rs = pstmt.getResultSet();
						closers();
						break;
					case 'q':
						// query with results set
						rs = stmt.executeQuery (sql);
						dispResultSet (rs);
						closers();
						break;
					case 'r':
						// repeat N times
						String count = tokens.nextToken();
						repeatCount = Integer.parseInt (count);
						gettingRepeatEntries = true;
						break;
					case 's':
						// set parameters and execute
						StringTokenizer st = new StringTokenizer (sql, ",;%", true);
						int i = 1;
						while (st.hasMoreTokens()) {
							token=st.nextToken();
							if (token.equals(" ")) continue;
							if (token.equals(";")) continue;
							if (token.equals(",")) continue;
							if (token.equals("%")) {
								// Anything between two % signs is a types specifier
								String typeSpecifier = st.nextToken();
								String percent = st.nextToken();
								token = st.nextToken();
								if (typeSpecifier.equalsIgnoreCase ("binaryStream")) {
									File file = new File(token);
									int fileLength = (int)file.length();
									InputStream fin = new FileInputStream(file);
									pstmt.setBinaryStream (i++, fin, fileLength);
								} else if (typeSpecifier.equalsIgnoreCase ("asciiStream")) {
									File file = new File(token);
									int fileLength = (int)file.length();
									InputStream fin = new FileInputStream(file);
									pstmt.setAsciiStream (i++, fin, fileLength);
								} else if (typeSpecifier.equalsIgnoreCase ("timestamp")) {
									Timestamp t = Timestamp.valueOf (token);
									pstmt.setTimestamp (i++, t);
								} else if (typeSpecifier.equalsIgnoreCase ("boolean")) {
									Boolean b = new Boolean (token);
									pstmt.setBoolean (i++, b.booleanValue());
								} else if (typeSpecifier.equalsIgnoreCase ("int array")) {
									StringTokenizer intTokens = new StringTokenizer (token, " ", false);
									int[] ints = new int[intTokens.countTokens()];
									int j=0;
									while (intTokens.hasMoreTokens()) {
										ints[j++] = Integer.parseInt(intTokens.nextToken());
									} // while
									pstmt.setObject (i++, ints);
								} else if (typeSpecifier.equalsIgnoreCase ("test object")) {
									TestObject tst = new TestObject (1, token, null);
									pstmt.setObject (i++, tst);
								} else {
									System.out.println ("Unknown type specifier: "+typeSpecifier);
								} // if-else
							} else {
								token=token.trim();
								pstmt.setString (i++, token);
							} // if-else
						} // while
						if (batchMode) {					// if batching statement
							pstmt.addBatch();
						} else {
							pstmt.executeUpdate();
						} // if-else
						break;
					case 't':
						// start off a thread with its own input file
						Thread newThread = new Thread (new SampleThread(sql));
						newThread.start();
						childThreads.addElement(newThread);
						break;
					case 'u':
						// update a results set
						String colname = tokens.nextToken();
						String value = tokens.nextToken();
						if (test1 != null) {				// if a test object exists
							rs.updateObject (colname, test1);
							test1 = null;
						} else {
							rs.updateString (colname, value);
						} // if-else
						break;
					default:
						throw new Exception ("Unknown command: "+command);
					} // switch
					diffTime = System.currentTimeMillis()-startTime;
				} catch (Exception e) {
					e.printStackTrace();
				} // try-catch
			} // while
		
			waitForChildren();

		} catch (Exception e) {
			e.printStackTrace ();
		} finally {
			try {
				in.close();
			} catch (Exception e) {
				e.printStackTrace ();
			} // try-catch
		} // try-catch

	} // method run


	/**
	 * Shows how to export all InstantDB tables to CSV delimited text files.
	 */
	void exportAll () throws SQLException {
		// get list of tables
		String[] types = {"TABLE"};
		ResultSet rs = dma.getTables (null,null,"%",types);	

		// Export each table in turn
		while (rs.next()) {
			String tableName = rs.getString (3);
			String sql = "SET EXPORT \"ex$"+tableName+".txt\" CSVDELIMITED NO SQL TRACE 0";
			stmt.execute (sql);
			sql = "SELECT * FROM "+tableName;
			stmt.execute (sql);
		} // while

		// makes sure future selects don't get exported to the last file
		String sql = "SET EXPORT \"NULL\"";
		stmt.execute (sql);
	} // method exportAll

	/**
	 * Shows how to re-import all instantDB tables from CSV files.
	 */
	void importAll () throws SQLException {
		// get list of tables
		String[] types = {"TABLE"};
		ResultSet rs = dma.getTables (null,null,"%",types);	

		// Import each table in turn
		while (rs.next()) {
			String tableName = rs.getString (3);
			String sql = "DELETE FROM "+tableName;
			stmt.execute (sql);
			sql = "IMPORT "+tableName+" FROM \"ex$"+tableName+".txt\" BUFFER 1024";
			stmt.execute (sql);
		} // while
	} // method importAll



	//-------------------------------------------------------------------
	// dispResultSet
	// Displays all columns and rows in the given result set
	//-------------------------------------------------------------------

	static void dispResultSet (ResultSet rs) throws SQLException {
		int i;

		ResultSetMetaData rsmd = rs.getMetaData ();
		int numCols = rsmd.getColumnCount ();

		for (i=1; i<=numCols; i++) {
			if (i > 1) System.out.print(",");
			System.out.print(rsmd.getColumnLabel(i));
		}
		System.out.println("");
		
		while (rs.next ()) 
			System.out.println (dispRow(rs));
	}

	/**
	 * Display the current row in the results set.
	 */
	static String dispRow (ResultSet rs) throws SQLException {
		ResultSetMetaData rsmd = rs.getMetaData ();
		int numCols = rsmd.getColumnCount ();
		StringBuffer sb = new StringBuffer (128);
		for (int i=1; i<=numCols; i++) {
			if (i > 1) sb.append (',');
			Object o = rs.getObject(i);
			if (o instanceof int[]) {
				sb.append (utils.getIntArrayAsString(o));
			} else {
				sb.append (rs.getString(i));
			} // if-else
		}
		return sb.toString();
	} // method dispRow

} // class SampleThread 

/**
 * Used to test out saving objects as blobs.
 */
class TestObject implements Serializable {

	int			id;
	String		name;
	TestObject	child;

	TestObject (int i, String n, TestObject t) {
		id = i;
		name = n;
		child = t;
	} // method TestObject

	public String toString () {
		String s = "My id is "+id+" and my name is "+name;
		if (child != null) {
			s = s + ". I have a child: "+child.toString();
		} // if
		return s;
	} // method toString
} // class TestObject