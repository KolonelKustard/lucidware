/*-----------------------------------------------------------------------------
 *
 * Enhydra InstantDB
 * The Initial Developer of the Original Code is Lutris Technologies Inc.
 * Portions created by Lutris are Copyright 1997-2000 Lutris Technologies Inc.
 * All Rights Reserved.
 *
 * The contents of this file are subject to the Enhydra Public License
 * Version 1.1 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 * www.enhydra.org/license/epl.html
 *
 * Software distributed under the License is distributed on an "ASIS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * -----------------------------------------------------------------------------
 * $Id: example_function.java,v 1.2 2000/07/19 09:00:22 pete Exp $
 * -----------------------------------------------------------------------------
 */
package org.enhydra.instantdb.db;	// <-- NOTE - MUST BE IN PACKAGE org.enhydra.instantdb.db

import org.enhydra.instantdb.db.SqlFunction;
import java.sql.SQLException;
import java.util.*;

/**
 * Implements an example of InstantDB's function extension mechanism.
 * You can add you own functions by using this example as a template.
 * See the db.SqlFunction javadoc for details.
 * <P>
 * The class which implements an InstantDB function <B>MUST</B> be in
 * the package "db". It must have a classname which is an all lower
 * case version of the name of the function being implemented.
 * <P>
 * This example class shows how to use all of the data types available
 * in InstantDB and all of the interface methods which need to be 
 * implemented.
 * <P>
 * The function is used in SQL as:<BR>
 * <BR>
 * EXAMPLE_FUNCTION (byte, int, string, long, date, currency, float, double, blob)<BR>
 * <BR>.
 */
class example_function implements SqlFunction {

	/**
	 * This method is called when the expression parser encounters a
	 * user defined function. It allows the function to check the
	 * number and types of parameters that will be passed to it.
	 */
	public int checkParameters (int[] parameterTypes) throws SQLException {
		// Set up an error string just in case.
		String usage = "Usage: EXAMPLE_FUNCTION (byte, int, string, long, "+
			"date, currency, float, double, blob)";

		// Check the number of parameters.
		int paramCount = parameterTypes.length;
		if (paramCount != 9) {
			throw new SQLException (usage);
		} // if

		// Now check each parameter type.
		for (int i=0; i<paramCount; i++) {
			switch (i) {
			case 0:
				if (parameterTypes[i] != TYPE_BYTE) throw new SQLException (usage);
				break;
			case 1:
				if (parameterTypes[i] != TYPE_INTEGER) throw new SQLException (usage);
				break;
			case 2:
				if (parameterTypes[i] != TYPE_STRING) throw new SQLException (usage);
				break;
			case 3:
				if (parameterTypes[i] != TYPE_LONG) throw new SQLException (usage);
				break;
			case 4:
				if (parameterTypes[i] != TYPE_DATE) throw new SQLException (usage);
				break;
			case 5:
				if (parameterTypes[i] != TYPE_CURRENCY) throw new SQLException (usage);
				break;
			case 6:
				if (parameterTypes[i] != TYPE_FLOAT) throw new SQLException (usage);
				break;
			case 7:
				if (parameterTypes[i] != TYPE_DOUBLE) throw new SQLException (usage);
				break;
			case 8:
				if (parameterTypes[i] != TYPE_BLOB) throw new SQLException (usage);
				break;
			} // switch
		} // for
		// Tell InstantDB what sort of result to expect.
		return TYPE_DOUBLE;
	} // checkParameters 

	/**
	 * InstantDB calls this method when it needs to pass additional
	 * information to a function. These could include configuration
	 * items or column specific information.
	 */
	public void setSpecialValue (int type, Object value) throws SQLException {
		if (type == MILLENIUM_BOUNDARY) {
			System.out.println ("The millenium boumdary is: "+value);
		} // if
	} // setSpecialValue

	/**
	 * InstantDB calls this method when it needs to be supplied with
	 * some additional information. For example, functions which return
	 * a date type will be invoked with type=DATE_FORMAT. This is InstantDB
	 * asking if any of the supplied parameters contains a date format
	 * string. If parameter 3 were a date format string then this method 
	 * would return an Integer object with the value 3 in it. If the
	 * information being requested is not available then just return null.
	 */
	public Object getSpecialValue (int type) throws SQLException {
		return null;
	} // getSpecialValue


	/**
	 * Evaluates the function. InstantDB passes in each of the parameters
	 * using the types corresponding to the parameters types
	 */
	public Object evaluate(Object[] parameters) throws SQLException {
		double result = 0;
		try {
			// Get all the parameters.
			int    b = ((Integer)parameters[0]).intValue();
			int    i = ((Integer)parameters[1]).intValue();
			int    s = ((String) parameters[2]).charAt(0);
			long   l = ((Long)   parameters[3]).longValue();
			long   t = ((Long)   parameters[4]).longValue();
			long   c = ((Long)   parameters[5]).longValue();
			float  f = ((Float)  parameters[6]).floatValue();
			double d = ((Double) parameters[7]).doubleValue();
			byte[] a =  (byte[]) parameters[8];

			result = b+i+s+l+t+c+f+d+a[0];
		} catch (Exception e) {
			throw new SQLException (e.getMessage());
		} // try-catch
		return new Double(result);
	} // evaluate


} // class example_function 
