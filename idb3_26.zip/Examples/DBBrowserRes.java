

package org.enhydra.instantdb;

import java.util.*;

public class DBBrowserRes extends java.util.ListResourceBundle {
  static final Object[][] contents = {
	{ "Enhydra_DBBrowser", "Enhydra DBBrowser" },
	{ "Center", "Center" },
	{ "Connecting_", "Connecting..." },
	{ "Connecting_to", "Connecting to " },
	{ "Connected_to", "Connected to " },
	{ "BLANK", " " },
	{ "KEY", "%" },
	{ "TABLE_NAME", "TABLE_NAME" },
	{ "Executing_", "Executing..." },
	{ "SQL_Executed", "SQL Executed" },
	{ "Disconnected", "Disconnected" },
	{ "Select_a_database", "Select a database" },
	{ "jdbc_idb_", "jdbc:idb:" },
	{ "KEY1", "," },
	{ "SELECT_FROM", "SELECT * FROM " },
	{ "_n", "\n" },
	{ "URL_", "URL:" },
	{ "jdbc_idb_XXX_prp", "jdbc:idb:XXX.prp" },
	{ "Connect", "Connect" },
	{ "SQL_", "SQL:" },
	{ "Submit", "Submit" },
	{ "Tables", "Tables" },
	{ "Results", "Results" },
	{ "Enter_a_URL_and_click", "Enter a URL and click on Connect" },
	{ "Disconnect", "Disconnect" },
	{ "Browse", "Browse" },
	{ "North", "North" },
	{ "South", "South" },
	{ "West", "West" },
	{ "East", "East" },
	{ "org_enhydra_instantdb", "org.enhydra.instantdb.jdbc.idbDriver" },
	{ "RmiJdbc_RJDriver", "RmiJdbc.RJDriver" },
	{ "sun_jdbc_odbc", "sun.jdbc.odbc.JdbcOdbcDriver" },
	{ "Loading_driver_", "Loading driver: " },
	{ "KEY2", "..." },
	{ "success", "success" },
	{ "failed_Error_", "failed. Error=" }};

  public Object[][] getContents() {
    return contents;
  }
}