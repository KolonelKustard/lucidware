/*-----------------------------------------------------------------------------
 *
 * Enhydra InstantDB
 * The Initial Developer of the Original Code is Lutris Technologies Inc.
 * Portions created by Lutris are Copyright 1997-2000 Lutris Technologies Inc.
 * All Rights Reserved.
 *
 * The contents of this file are subject to the Enhydra Public License
 * Version 1.1 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 * www.enhydra.org/license/epl.html
 *
 * Software distributed under the License is distributed on an "ASIS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * -----------------------------------------------------------------------------
 * $Id: DBBrowser.java,v 1.5 2000/11/30 12:50:47 pete Exp $
 * -----------------------------------------------------------------------------
 */
package org.enhydra.instantdb;

import java.awt.*;
import java.applet.*;
import java.util.*;

public class DBBrowser extends Frame {

	static DBBrowser fr;						// frame that holds the applet
	static ResourceBundle res = ResourceBundle.getBundle("org.enhydra.instantdb.DBBrowserRes");
	static JDBCAppl app;						// applet itself

    /**
	 * Used when the JDBCAppl class is run as an application rather than an Applet.
	 */
	public static void main (String args[]) {
		fr = new DBBrowser();								// create a frame to hold the applet
		fr.setTitle (res.getString("Enhydra_DBBrowser"));
		app = new JDBCAppl ();								// create an instance of the applet
		app.resize(500,500);
		fr.add (res.getString("Center"), app);								// add the frame to the applet
		fr.setSize (600,600);								// resize to preferred size
		app.init();											// initialize applet
		if (args.length > 0) {								// if arguments supplied
			app.setUrl (args[0]);							// interpret first arg as URL
		} // if
		fr.show();											// make frame visible
	} // method main

	public boolean handleEvent(Event evt) {
		switch (evt.id)	{
		case Event.WINDOW_DESTROY:
			app.destroy();									// close the connection to the database
			dispose();
			System.exit(0);
			return true;
		default:
			return super.handleEvent(evt);
		}			 
	}


} // Class JDBCAppl

