/*-----------------------------------------------------------------------------
 *
 * Enhydra InstantDB
 * The Initial Developer of the Original Code is Lutris Technologies Inc.
 * Portions created by Lutris are Copyright 1997-2000 Lutris Technologies Inc.
 * All Rights Reserved.
 *
 * The contents of this file are subject to the Enhydra Public License
 * Version 1.1 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 * www.enhydra.org/license/epl.html
 *
 * Software distributed under the License is distributed on an "ASIS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * -----------------------------------------------------------------------------
 * $Id: EncryptTest.java,v 1.3 2000/08/09 12:51:23 pete Exp $
 * -----------------------------------------------------------------------------
 */

/*
 * Set tab=4 for optimum viewing.
 */

package org.enhydra.instantdb;

import java.sql.*;
import org.enhydra.instantdb.jdbc.idbConnection;
import org.enhydra.instantdb.db.TableEncrypt;

/**
 * This is intended to show an example of InstantDB data encryption.
 * Two tables are created, one is held in clear, the other is
 * encrypted using a RowEncrypt object.
 * <P>
 * The same data is inserted into both tables. Some inserts are
 * direct, others are from an import.
 * <P>
 * The tables can be examined using a binary editor to demonstrate
 * the effect of the encryption.
 */
class EncryptTest {

	static String[] createSQL = {
		"DROP TABLE clear",
		"DROP TABLE encrypted",
		"CREATE TABLE clear     (int1 INT PRIMARY KEY, char1 CHAR (10), text1 TEXT)",
		"CREATE TABLE encrypted (int1 INT PRIMARY KEY, char1 CHAR (10), text1 TEXT)"
	};

	static String[] querySQL = {
		"SELECT * FROM encrypted",
		"SELECT * FROM clear",
		"SELECT * FROM encrypted WHERE int1 > 6",
		"SELECT * FROM clear WHERE int1 > 6"
	};

	static idbConnection con;
	static Statement stmt;

	/**
	 * Puts some data into one of the tables
	 */
	static void populateTable (String tableName, int count) throws SQLException {
		PreparedStatement prep = con.prepareStatement ("INSERT INTO ? VALUES (?, ?, ?)");
		prep.setString (1, tableName);
		for (int i=0; i<count; i++) {
			prep.setInt (2, i);
			prep.setString (3, String.valueOf(i));
			prep.setString (4, String.valueOf(i));
			prep.execute();
		} // for
		prep.close();
	} // method populateTable

	/**
	 * Executes an array of SQL statements
	 */
	static void execSQLs (String[] sqls) throws SQLException {
		for (int i=0; i<sqls.length; i++) {
			stmt.execute (sqls[i]);
			ResultSet rs = stmt.getResultSet();
			if (rs != null) {
				dispResultSet (rs);
				rs.close();
			} // if
		} // for
	} // method execSQLs

	/**
	 * Opens the database
	 */
	static void openDatabase () throws SQLException {
		if (con != null) {									// if already open
			stmt.close();									// close everthing first
			con.close();
		} // if
		con = (idbConnection)DriverManager.getConnection ("jdbc:idb:sample.prp");
		stmt = con.createStatement ();
	} // method openDatabase


	public static void main (String[] args) {
		try {
			Class.forName ("org.enhydra.instantdb.jdbc.idbDriver").newInstance();

			openDatabase();									// open the database

			execSQLs (createSQL);							// create the tables

			RowEncrypt re = new RowEncrypt ("myPassword");	// create a new row encryptor
			con.setTableEncryption ("encrypted", re);		// ensure table gets encrypted

			populateTable ("clear", 10);					// put some data in the tables
			populateTable ("encrypted", 10);
			stmt.execute ("IMPORT encrypted FROM 'encrypted.txt' USING 'schema.ini'");
			stmt.execute ("IMPORT clear FROM 'encrypted.txt'");

			execSQLs (querySQL);							// query the tables

			// re-open, but use the wrong decryption password

			openDatabase();									// close and open the database
			re = new RowEncrypt ("wrongPassword");
			con.setTableEncryption ("encrypted", re);

			try {
				execSQLs (querySQL);						// try to query the tables
			} catch (Exception e) {
				System.out.println (e);						// get ready for errors
			} // try-catch

			// Use the correct password

			openDatabase();									// close and open the database
			re = new RowEncrypt ("myPassword");
			con.setTableEncryption ("encrypted", re);
			execSQLs (querySQL);

			stmt.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		} // try-catch
	} // method Main

	private static void dispResultSet (ResultSet rs) throws SQLException {
		ResultSetMetaData rsmd = rs.getMetaData ();
		int numCols = rsmd.getColumnCount ();

		for (int i=1; i<=numCols; i++) {
			if (i > 1) System.out.print(",");
			System.out.print(rsmd.getColumnLabel(i));
		}
		System.out.println("");
		
		while (rs.next ()) {
			for (int i=1; i<=numCols; i++) {
				if (i > 1) System.out.print(",");
				System.out.print(rs.getString(i));
			}
			System.out.println("");
		}
	} // method dispResultSet

} // class EncryptTest 