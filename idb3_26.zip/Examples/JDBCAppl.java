/*-----------------------------------------------------------------------------
 *
 * Enhydra InstantDB
 * The Initial Developer of the Original Code is Lutris Technologies Inc.
 * Portions created by Lutris are Copyright 1997-2000 Lutris Technologies Inc.
 * All Rights Reserved.
 *
 * The contents of this file are subject to the Enhydra Public License
 * Version 1.1 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 * www.enhydra.org/license/epl.html
 *
 * Software distributed under the License is distributed on an "ASIS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * -----------------------------------------------------------------------------
 * $Id: JDBCAppl.java,v 1.4 2001/01/13 14:17:52 pete Exp $
 * -----------------------------------------------------------------------------
 */
package org.enhydra.instantdb;

import java.applet.*;
import java.awt.*;
import java.sql.*;
import java.util.Properties;
import java.util.Enumeration;
import java.util.Vector;

import org.enhydra.instantdb.jdbc.*;

public class JDBCAppl extends Applet {

	Connection			con;					// the database connection
	Label				urlLabel;				// label set to URL:
	public TextField	urlText;				// holds the current URL
	Button				connectButton;			// used to start a database connection
	Label				sqlLabel;				// holds the SQL: prompt
	public TextField	sqlText;				// holds the current SQL statement
	Button				submitButton;			// used to submit the SQL
	Label				tableLabel;				// holds the Tables label
	Label				outputLabel;			// holds the Output label
	List				tableList;				// holds list of tables
	public List			rowList;				// list of rows selected
	Label				statusLabel;			// show operational status
	Button				disconnectButton;		// used to disconnect
	Button				browseButton;			// used to browse for a url
	FileDialog			urlBrowse;				// the file dialog used to browse
	public TextArea		displayText;			// used to show full contents of selected row
	Label				scriptLabel;			// holds the "Script" label
	TextField			scriptText;				// holds the script name
	FileDialog			scriptBrowse;			// the file dialog used to browse scripts
	Button				runButton;				// used to run a script
	Button				findScriptButton;		// used to browse for a script

	Vector vectorStatements;
	int iStatementPointer;

	/**
	 * connect to a database using the current url.
	 */
	void connectToDatabase () throws SQLException {
		statusLabel.setText ("Connecting...");
		System.out.println ("Connecting to "+urlText.getText());
		con = DriverManager.getConnection (urlText.getText());
		DatabaseMetaData dbmd = con.getMetaData();
		statusLabel.setText ("Connected to "
			+dbmd.getDatabaseProductName()+" "
			+dbmd.getDatabaseProductVersion());
		ResultSet rs = dbmd.getTables (null,null,"%",null);
		addResultstoList (rs, tableList, "TABLE_NAME");
		rs.close();
	} // method connectToDatabase

	/**
	 * Handles a button click.
	 */
	public boolean action (Event evt, Object what) {
		try {
			if (evt.target==submitButton || evt.target==sqlText) {					// check for submit SQL
				String sSql = sqlText.getText();
				if(!vectorStatements.contains(sSql))
				{
					vectorStatements.addElement(sSql);
					iStatementPointer = vectorStatements.size();
				}
				statusLabel.setText ("Executing...");
				Statement stmt = con.createStatement ();

				if (stmt.execute(sSql)) 
				{
					// Result set available
					ResultSet rs = stmt.getResultSet();
					String colNames = addResultstoList (rs, rowList, null);
					outputLabel.setText (colNames);
					rs.close();
				} // if
				statusLabel.setText ("SQL Executed");
				stmt.close();
				return true;
			} else if (evt.target==connectButton || evt.target == this.urlText) {			// check for connect
				connectToDatabase();
				return true;
			} else if (evt.target==disconnectButton) {		// check for disconnect
				if (con != null) con.close();
				con=null;
				statusLabel.setText ("Disconnected");
			} else if (evt.target==browseButton) {			// check for url browse
				if (urlBrowse==null) {						// if not created yet
					urlBrowse=new FileDialog (
						(Frame)getParent(), "Select a database", FileDialog.LOAD);
				} // if
				urlBrowse.show();
				urlText.setText ("jdbc:idb:"
					+urlBrowse.getDirectory()+urlBrowse.getFile());
			} else if (evt.target==findScriptButton) {		// check for script browse
				if (scriptBrowse==null) {					// if not created yet
					scriptBrowse=new FileDialog (
						(Frame)getParent(), "Select a script", FileDialog.LOAD);
				} // if
				scriptBrowse.show();
				scriptText.setText (scriptBrowse.getDirectory()+scriptBrowse.getFile());
			} else if (evt.target==runButton || evt.target == scriptText) {
				// run a script
				String[] args = new String[1];
				args[0] = scriptText.getText();
				ScriptTool.main(args);
			} // if-else
		} catch (Exception e) {
			statusLabel.setText (e.toString());
			e.printStackTrace();
		} // try-catch
		return false;
	} // method action
	/**
	 *
	 */
	private String addResultstoList (ResultSet rs, List ls, String colName) {
		StringBuffer curRow = new StringBuffer (500);		// create a bug string buffer

		try {
			ls.removeAll();									// clear out the list

			ResultSetMetaData rsmd = rs.getMetaData ();		// get results set info
			int numCols = rsmd.getColumnCount ();			// get number of columns

			while (rs.next ()) {							// while more rows
				curRow.setLength (0);						// clear out the buffer
				for (int i=1; i<=numCols; i++) {			// for each column
					if (colName != null) {					// if only one col reqd
						if (!rsmd.getColumnLabel(i).equalsIgnoreCase(colName))
							continue;
					} // if
					if (curRow.length() > 0) curRow.append(",");// check for later columns
					curRow.append(rs.getString(i));			// add to cur row
				}
				ls.add (curRow.toString());					// add row to list
			}

			curRow.setLength (0);							// clear out the buffer
			for (int i=1; i<=numCols; i++) {				// for each column header
				if (curRow.length() > 0) curRow.append(",");// check for comma to separate
				curRow.append(rsmd.getColumnLabel(i));		// and add new column header
			}
			
		} catch (Exception e) {
			statusLabel.setText (e.toString());
			e.printStackTrace();
		} // try-catch
		return curRow.toString();							// return columns headers
	} // method addResultstoList


	/**
	 *
	 */
	public void destroy () {
		try {
			if (con != null) con.close();
		} catch (Exception e) {
			statusLabel.setText (e.toString());
			e.printStackTrace();
		} // try-catch
	} // method destroy


	/**
	 * Handles the list selection event.
	 */
	public boolean handleEvent (Event evt) {
		if (evt.target == tableList &&						// if the table list
			evt.id == Event.LIST_SELECT) {					// and a select event
				sqlText.setText("SELECT * FROM "+tableList.getSelectedItem());
			return true;
		} // if
		if (evt.target == rowList &&						// if the row list
			evt.id == Event.LIST_SELECT) {					// and a select event
				displayText.append("\n"+rowList.getSelectedItem());
			return true;
		} // if
		if(evt.target == sqlText)
		{
			if(evt.id == evt.KEY_ACTION_RELEASE)
			{
				if(evt.key == evt.DOWN)
				{
					if(iStatementPointer+1 == vectorStatements.size())
					{
						sqlText.setText("");
					}
					else if(iStatementPointer < vectorStatements.size())
					{
						iStatementPointer++;
						sqlText.setText((String)vectorStatements.elementAt(iStatementPointer));
						return true;
					}
				}
				else if(evt.key == evt.UP)
				{
					if(iStatementPointer > 0)
					{
						iStatementPointer--;
						sqlText.setText((String)vectorStatements.elementAt(iStatementPointer));
						return true;
					}
				}
			}
		}
		return super.handleEvent (evt);						// let Applet handle it
	} // method handleEvent


	public void init () {
		try {
			DriverManager.setLogStream (System.out);
			loadDrivers();

			// create the components for the applet
			urlLabel = new Label ("URL:");
			urlText = new TextField	("jdbc:idb:XXX.prp");
			connectButton = new Button ("Connect");
			sqlLabel = new Label ("SQL:");
			sqlText= new TextField ("");
			submitButton = new Button ("Submit");
			tableLabel = new Label ("Tables");
			outputLabel = new Label ("Results");
			tableList = new List ();
			rowList = new List();
			statusLabel = new Label ("Enter a URL and click on Connect");
			disconnectButton = new Button ("Disconnect");
			browseButton = new Button ("Browse");
			displayText = new TextArea(4,40);
			scriptLabel = new Label ("Script");
			scriptText = new TextField ("");
			runButton = new Button ("Run");
			findScriptButton = new Button ("Browse");
			vectorStatements = new Vector();

			// overall layout is 3 panels - top, center and bottom
			Panel top = new Panel ();						// top part of applet
			Panel center = new Panel ();					// center part of applet
			setLayout (new BorderLayout(5,5));				// overall layout is a NSEWC one
			add ("North", top);
			add ("Center", center);
			add ("South", displayText);
			
			// set the top panel - consists of three more horizontally arranged panels
			top.setLayout (new BorderLayout(5, 5));			// give it distinct center
			Panel topLeft = new Panel ();					// holds the prompt labels
			Panel topCenter = new Panel ();					// holds the text fields
			Panel topRight = new Panel ();					// holds the buttons
			top.add ("West", topLeft);
			top.add ("Center", topCenter);
			top.add ("East", topRight);

			// Each of the top panels has a 3 rows x 1 col grid (2 for right panel)
			topLeft.setLayout (new GridLayout (3,1,5,5));
			topCenter.setLayout (new GridLayout (3,1,5,5));
			topRight.setLayout (new GridLayout (3,2,5,5));

			// finally - add all the top components
			topLeft.add (urlLabel);
			topLeft.add (sqlLabel);
			topLeft.add (scriptLabel);
			topCenter.add (urlText);
			topCenter.add (sqlText);
			topCenter.add (scriptText);
			topRight.add (connectButton);
			topRight.add (browseButton);
			topRight.add (submitButton);
			topRight.add (disconnectButton);
			topRight.add (runButton);
			topRight.add (findScriptButton);

			// Center panel consists of two more horizontally arranged panels
			center.setLayout (new BorderLayout(5, 5));		// give it distinct center
			Panel centerLeft = new Panel ();				// holds the tables
			Panel centerCenter = new Panel ();				// holds the results
			center.add ("West", centerLeft);
			center.add ("Center", centerCenter);

			// Each of the center panels has a north and a center
			centerLeft.setLayout (new BorderLayout (5,5));
			centerCenter.setLayout (new BorderLayout (5,5));

			// finally add the center components
			centerLeft.add ("North", tableLabel);
			centerCenter.add ("North", outputLabel);
			centerLeft.add ("Center", tableList);
			centerCenter.add ("Center", rowList);
			centerCenter.add ("South", statusLabel);

			StringBuffer rowEntry = new StringBuffer (500);
			Properties sysProps = System.getProperties();		// get the systen properties
			Enumeration propNames = sysProps.propertyNames();// get their names
			while (propNames.hasMoreElements()) {
				String propName = (String)propNames.nextElement();	// get next name
				rowEntry.setLength(0);						// clear down buffer
				rowEntry.append (propName);					// set prop name
				rowEntry.append ('=');
				try {
					rowEntry.append (System.getProperty (propName));
				} catch (Exception e) {
					rowEntry.append (e.toString());
				} // try-catch
				rowList.add (rowEntry.toString());
			} // while
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	} // init


	/**
	 * Loads some popular JDBC drivers.
	 */
	void loadDrivers () {
		String[] drivers = {"org.enhydra.instantdb.jdbc.idbDriver", 
					"RmiJdbc.RJDriver", 
					"sun.jdbc.odbc.JdbcOdbcDriver"};
		for (int i=0; i<drivers.length; i++) {
			try {
				System.out.print ("Loading driver: "+drivers[i]+"...");
				Class.forName (drivers[i]).newInstance();
				System.out.println ("success");
			} catch (Exception e) {
				System.out.println ("failed. Error="+e);
			} // try-catch
		} // for
	} // method loadDrivers


	/**
	 * Sets the URL 
	 */
	void setUrl (String s) {
		urlText.setText(s);
		try {
			connectToDatabase();
		} catch (Exception e) {
			statusLabel.setText (e.toString());
			e.printStackTrace();
		} // try-catch
	} // method setUrl
} // Class JDBCAppl
